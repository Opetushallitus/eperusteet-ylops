"use strict";
ylopsApp
    .controller("UusiOpsController", function ($scope, $state, OpsListaService, Utils) {
    $scope.pohja = {
        active: 0,
        model: null
    };
    $scope.addNew = function () {
        var pohjaId = null;
        if ($scope.pohja.active === "1" && $scope.pohja.model) {
            pohjaId = $scope.pohja.model.id;
        }
        $state.go("root.opetussuunnitelmat.yksi.tiedot", { id: "uusi", pohjaId: pohjaId });
    };
    OpsListaService.query(false).then(function (pohjat) {
        $scope.pohjat = pohjat;
    });
    $scope.sorter = Utils.sort;
})
    .controller("EtusivuController", function ($scope, Oikeudet, $state, OpetussuunnitelmaOikeudetService) {
    $scope.isVirkailija = Oikeudet.isVirkailija;
    $scope.hasLuontiOps = OpetussuunnitelmaOikeudetService.onkoOikeudet("opetussuunnitelma", "luonti", true);
    $scope.hasLuontiPohja = OpetussuunnitelmaOikeudetService.onkoOikeudet("pohja", "luonti", true);
    $scope.hasLuontiBox = $scope.hasLuontiOps || $scope.hasLuontiPohja;
    $scope.addNewPohja = function () {
        $state.go("root.pohjat.yksi.tiedot", { pohjaId: "uusi" });
    };
});
//# sourceMappingURL=etusivu.js.map