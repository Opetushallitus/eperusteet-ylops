"use strict";
ylopsApp
    .service("OpsinTila", function ($modal, OpetussuunnitelmaCRUD, Notifikaatiot) {
    this.palauta = function (ops, cb) {
        OpetussuunnitelmaCRUD.palauta({ opsId: ops.id }, null, cb, Notifikaatiot.serverCb);
    };
    this.save = function (ops, tila, cb) {
        if (cb === void 0) { cb = _.noop; }
        OpetussuunnitelmaCRUD.setTila({ opsId: ops.id, tila: tila })
            .$promise.then(cb)["catch"](function () {
            OpetussuunnitelmaCRUD.validoi({ opsId: ops.id }).$promise.then(function (res) {
                $modal
                    .open({
                    templateUrl: "views/opetussuunnitelmat/modals/validointivirheet.html",
                    controller: "ValidointivirheetController",
                    size: "lg",
                    resolve: { virheet: _.constant(res) }
                })
                    .result.then(_.noop);
            });
        });
    };
})
    .service("OpsinTilanvaihto", function ($modal) {
    var that = this;
    this.start = function (parametrit, setFn, successCb) {
        if (successCb === void 0) { successCb = _.noop; }
        if (_.isFunction(setFn)) {
            that.setFn = setFn;
        }
        $modal
            .open({
            templateUrl: "views/opetussuunnitelmat/modals/tilanvaihto.html",
            controller: "OpsinTilanvaihtoController",
            resolve: {
                data: function () {
                    return {
                        isPohja: parametrit.isPohja,
                        oldStatus: parametrit.currentStatus,
                        mahdollisetTilat: parametrit.mahdollisetTilat,
                        statuses: _.map(parametrit.mahdollisetTilat, function (item) {
                            return { key: item, description: "tilakuvaus-" + item };
                        })
                    };
                }
            }
        })
            .result.then(function (res) {
            that.setFn(res);
            successCb(res);
        });
    };
    this.set = function (status, successCb) {
        that.setFn(status, successCb);
    };
})
    .controller("ValidointivirheetController", function ($scope, $modalInstance, $state, virheet) {
    var create = function (l, field) {
        return _(l)
            .map(field)
            .flatten()
            .value();
    };
    $scope.virheet = create(virheet, "virheet");
    $scope.varoitukset = create(virheet, "varoitukset");
    $scope.huomiot = create(virheet, "huomiot");
    $scope.eiVirheita = _.isEmpty($scope.virheet) && _.isEmpty($scope.varoitukset) && _.isEmpty($scope.huomiot);
    $scope.ok = $modalInstance.dismiss;
})
    .controller("OpsinTilanvaihtoController", function ($scope, $modalInstance, $state, data) {
    $scope.data = data;
    $scope.data.selected = null;
    $scope.data.editable = false;
    $scope.title = data.isPohja ? "aseta-pohjan-tila" : "aseta-opsin-tila";
    $scope.valitse = function () {
        $modalInstance.close($scope.data.selected);
    };
    $scope.peruuta = function () {
        $modalInstance.dismiss();
    };
});
//# sourceMappingURL=tila.js.map