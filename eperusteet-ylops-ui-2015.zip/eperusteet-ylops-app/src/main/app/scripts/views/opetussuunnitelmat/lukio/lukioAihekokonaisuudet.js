"use strict";
ylopsApp
    .controller("AihekokonaisuudetController", function ($scope, $state, Editointikontrollit, $q, LukioOpetussuunnitelmaService, $timeout, $stateParams, Notifikaatiot, Kaanna) {
    $scope.aihekokonaisuudet = {};
    $scope.sortableModel = [];
    $scope.editMode = false;
    $scope.yleiskuvaEditMode = false;
    LukioOpetussuunnitelmaService.getAihekokonaisuudet().then(function (ak) {
        $scope.aihekokonaisuudet = ak;
        $scope.sortableModel = ak.paikallinen.aihekokonaisuudet;
    });
    $scope.sortableOptions = {
        disabled: true
    };
    $scope.toEditMode = function () {
        Editointikontrollit.registerCallback({
            validate: function () {
                return true;
            },
            edit: function () {
                return $q(function (resolve) {
                    LukioOpetussuunnitelmaService.lukitseAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () { return resolve(); });
                });
            },
            cancel: function () {
                return $q(function (resolve) {
                    LukioOpetussuunnitelmaService.vapautaAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () {
                        resolve();
                        $timeout(function () { return $state.reload(); });
                    });
                });
            },
            save: function () {
                return $q(function (resolve) {
                    $scope.editmode = false;
                    $scope.sortableOptions.disabled = true;
                    LukioOpetussuunnitelmaService.rearrangeAihekokonaisuudet({
                        aihekokonaisuudet: _.each($scope.sortableModel, function (i) { return _.pick(i, "id"); })
                    }).then(function () {
                        Notifikaatiot.onnistui("aihekokonaisuuksien-jarjestaminen-onnistui");
                        LukioOpetussuunnitelmaService.vapautaAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () {
                            resolve();
                            $timeout(function () { return $state.reload(); });
                        });
                    });
                });
            }
        });
        $scope.sortableOptions.disabled = false;
        $scope.editMode = true;
        Editointikontrollit.startEditing();
    };
    $scope.toYleiskuvausEditMode = function () {
        Editointikontrollit.registerCallback({
            validate: function () {
                return true;
            },
            edit: function () {
                return $q(function (resolve) {
                    LukioOpetussuunnitelmaService.lukitseAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () { return resolve(); });
                });
            },
            cancel: function () {
                return $q(function (resolve) {
                    LukioOpetussuunnitelmaService.vapautaAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () {
                        resolve();
                        $timeout(function () { return $state.reload(); });
                    });
                });
            },
            save: function () {
                return $q(function (resolve) {
                    $scope.yleiskuvaEditMode = false;
                    LukioOpetussuunnitelmaService.updateAihekokonaisuudetYleiskuvaus({
                        otsikko: $scope.aihekokonaisuudet.paikallinen.otsikko,
                        yleiskuvaus: $scope.aihekokonaisuudet.paikallinen.yleiskuvaus
                    }).then(function () {
                        Notifikaatiot.onnistui("aihekokonaisuuksien-yleiskuvauksen-paivitys-onnistui");
                        LukioOpetussuunnitelmaService.vapautaAihekokonaisuudet($scope.aihekokonaisuudet.paikallinen.id).then(function () {
                            resolve();
                            $timeout(function () { return $state.reload(); });
                        });
                    });
                });
            }
        });
        $scope.yleiskuvaEditMode = true;
        Editointikontrollit.startEditing();
    };
    $scope.addAihekokonaisuus = function () {
        $timeout(function () {
            return $state.go("root.opetussuunnitelmat.lukio.opetus.uusiaihekokonaisuus", {
                id: $stateParams.id
            });
        });
    };
})
    .controller("AihekokonaisuusController", function ($scope, $state, $stateParams, Varmistusdialogi, Editointikontrollit, $q, $timeout, $log, Notifikaatiot, Kaanna, LukioOpetussuunnitelmaService) {
    $scope.aihekokonaisuus = null;
    $scope.editMode = false;
    LukioOpetussuunnitelmaService.getAihekokonaisuus($stateParams.aihekokonaisuusId).then(function (ak) {
        $scope.aihekokonaisuus = ak;
    });
    $scope.isDeletable = function () {
        return $scope.aihekokonaisuus && !$scope.aihekokonaisuus.perusteen && !$scope.aihekokonaisuus.parent;
    };
    Editointikontrollit.registerCallback({
        validate: function () {
            return Kaanna.kaanna($scope.aihekokonaisuus.otsikko);
        },
        edit: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.lukitseAihekokonaisuus($scope.aihekokonaisuus.id).then(function () {
                    return resolve();
                });
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.vapautaAihekokonaisuus($scope.aihekokonaisuus.id).then(function () {
                    $timeout(function () { return $state.reload(); });
                    resolve();
                });
            });
        },
        save: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.updateAihekokonaisuus($stateParams.aihekokonaisuusId, $scope.aihekokonaisuus).then(function () {
                    Notifikaatiot.onnistui("aihekokonaisuuden-tallentaminen-onnistui");
                    LukioOpetussuunnitelmaService.vapautaAihekokonaisuus($scope.aihekokonaisuus.id).then(function () {
                        $timeout(function () { return $state.reload(); });
                        resolve();
                    });
                });
                resolve();
            });
        }
    });
    $scope.toEditMode = function () {
        $scope.editMode = true;
        Editointikontrollit.startEditing();
    };
    $scope.deleteKokonaisuus = function () {
        return Varmistusdialogi.dialogi({
            otsikko: "varmista-poista-aihekokonaisuus",
            primaryBtn: "poista",
            successCb: function () {
                return LukioOpetussuunnitelmaService.deleteAihekokonaisuus($stateParams.aihekokonaisuusId).then(function () {
                    Notifikaatiot.onnistui("aihekokonaisuuden-poisto-onnistui");
                    $timeout(function () {
                        return $state.go("root.opetussuunnitelmat.lukio.opetus.aihekokonaisuudet", {
                            id: $stateParams.id
                        });
                    });
                });
            }
        })();
    };
})
    .controller("LuoAihekokonaisuusController", function ($scope, $state, $stateParams, Kaanna, Editointikontrollit, $q, $timeout, LukioControllerHelpers, Notifikaatiot, LukioOpetussuunnitelmaService) {
    $scope.aihekokonaisuus = {
        otsikko: LukioControllerHelpers.kielella(""),
        yleiskuvaus: LukioControllerHelpers.kielella("")
    };
    $scope.editMode = true;
    Editointikontrollit.registerCallback({
        validate: function () {
            return Kaanna.kaanna($scope.aihekokonaisuus.otsikko);
        },
        edit: function () {
            return $q(function (resolve) {
                resolve();
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                $timeout(function () {
                    return $state.go("root.opetussuunnitelmat.lukio.opetus.aihekokonaisuudet", {
                        id: $stateParams.id
                    });
                });
                resolve();
            });
        },
        save: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.saveAihekokonaisuus($scope.aihekokonaisuus).then(function (res) {
                    Notifikaatiot.onnistui("aihekokonaisuuden-tallentaminen-onnistui");
                    $timeout(function () {
                        return $state.go("root.opetussuunnitelmat.lukio.opetus.aihekokonaisuus", {
                            id: $stateParams.id,
                            aihekokonaisuusId: res.id
                        });
                    });
                    resolve();
                });
            });
        }
    });
    Editointikontrollit.startEditing();
});
//# sourceMappingURL=lukioAihekokonaisuudet.js.map