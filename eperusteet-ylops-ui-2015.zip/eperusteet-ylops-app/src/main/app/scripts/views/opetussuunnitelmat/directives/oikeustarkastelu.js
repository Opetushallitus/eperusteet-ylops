"use strict";
ylopsApp
    .directive("oikeustarkastelu", function (OpetussuunnitelmaOikeudetService) {
    return {
        restrict: "A",
        link: function postLink(scope, element, attrs) {
            var oikeudet = scope.$eval(attrs.oikeustarkastelu);
            if (!angular.isArray(oikeudet)) {
                oikeudet = [oikeudet];
            }
            if (!_.any(oikeudet, function (o) {
                return OpetussuunnitelmaOikeudetService.onkoOikeudet(o.target, o.permission);
            })) {
                element.hide();
            }
        }
    };
})
    .directive("kayttajaoikeustarkastelu", function (OpetussuunnitelmaOikeudetService) {
    return {
        restrict: "A",
        link: function postLink(scope, element, attrs) {
            var oikeudet = scope.$eval(attrs.kayttajaoikeustarkastelu);
            if (!angular.isArray(oikeudet)) {
                oikeudet = [oikeudet];
            }
            if (!_.any(oikeudet, function (o) {
                return OpetussuunnitelmaOikeudetService.onkoOikeudet(o.target, o.permission, true);
            })) {
                element.hide();
            }
        }
    };
});
//# sourceMappingURL=oikeustarkastelu.js.map