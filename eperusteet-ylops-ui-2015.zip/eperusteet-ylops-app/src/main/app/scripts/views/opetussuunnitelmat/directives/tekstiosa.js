"use strict";
ylopsApp
    .directive("perusteenTekstiosa", function ($timeout, $window) {
    return {
        restrict: "A",
        scope: {
            model: "=perusteenTekstiosa",
            muokattava: "=?",
            callbacks: "=",
            startCollapsed: "=?",
            ohjepallo: "=",
            shouldDisable: "="
        },
        templateUrl: "views/opetussuunnitelmat/directives/tekstiosa.html",
        controller: "TekstiosaController",
        link: function (scope, element, attrs) {
            scope.editable = !!attrs.muokattava;
            scope.focusAndScroll = function () {
                $timeout(function () {
                    var el = element.find("[ckeditor]");
                    if (el && el.length > 0) {
                        el[0].focus();
                        $window.scrollTo(0, el.eq(0).offset().top - 200);
                    }
                }, 300);
            };
        }
    };
})
    .directive("yksinkertainenTekstiosa", function ($timeout, $window) {
    return {
        restrict: "A",
        scope: {
            model: "=yksinkertainenTekstiosa",
            callbacks: "=",
            startCollapsed: "=?",
            otsikko: "@?",
            shouldDisable: "="
        },
        templateUrl: "views/opetussuunnitelmat/directives/yksinkertainentekstiosa.html",
        controller: "TekstiosaController",
        link: function (scope, element) {
            scope.focusAndScroll = function () {
                $timeout(function () {
                    var el = element.find("[ckeditor]");
                    if (el && el.length > 0) {
                        el[0].focus();
                        $window.scrollTo(0, el.eq(0).offset().top - 200);
                    }
                }, 300);
            };
        }
    };
})
    .controller("TekstiosaController", function ($state, $scope, $q, Editointikontrollit, Kieli) {
    $scope.editMode = false;
    $scope.collapsed = _.isUndefined($scope.startCollapsed) ? true : $scope.startCollapsed;
    function validoi() {
        if ($scope.muokattava) {
            $scope.muokattava.otsikko = $scope.muokattava.otsikko || {};
            $scope.muokattava.otsikko.$$validointi = Kieli.validoi($scope.muokattava.otsikko);
            $scope.muokattava.teksti = $scope.muokattava.teksti || {};
            $scope.muokattava.teksti.$$validointi = Kieli.validoi($scope.muokattava.teksti);
        }
    }
    $scope.$watch("muokattava", validoi, true);
    function notifyFn(mode) {
        $scope.editMode = mode;
        if (!mode) {
            $scope.callbacks.notifier = angular.noop;
        }
    }
    $scope.startEditing = function () {
        $scope.editMode = true;
        $scope.callbacks.notifier = notifyFn;
        $scope.focusAndScroll();
        validoi();
        Editointikontrollit.startEditing().then(function () { return $q.when(); });
    };
    $scope.remove = function () {
        $scope.callbacks.remove($scope.muokattava);
    };
});
//# sourceMappingURL=tekstiosa.js.map