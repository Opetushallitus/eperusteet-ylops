"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
ylopsApp.controller("PohjaTiedotController", function ($scope, $stateParams, $state, $q, OpetussuunnitelmaCRUD, Notifikaatiot, Utils, OpsService, $rootScope, Editointikontrollit, $timeout, Kieli, Varmistusdialogi, EperusteetPerusopetus, EperusteetLukiokoulutus, EperusteetValmiitPerusteet, perusteet) {
    $scope.luonnissa = $stateParams.pohjaId === "uusi";
    $scope.yksinkertainen = _.any(["koulutustyyppi_6", "koulutustyyppi_15", "koulutustyyppi_20", "koulutustyyppi_22"], function (i) { return i === $scope.model.koulutustyyppi; });
    $scope.kieliOrderFn = Kieli.orderFn;
    if ($scope.luonnissa) {
        $scope.model.tyyppi = "pohja";
        $scope.model.julkaisukielet = ["fi"];
    }
    $scope.editMode = false;
    $scope.kielivalinnat = ["fi", "sv", "se"];
    $scope.perustelista = [];
    $scope.hasRequiredFields = function () {
        var model = $scope.model;
        return (Utils.hasLocalizedText(model.nimi) && model.perusteenDiaarinumero && _.any(_.values($scope.julkaisukielet)));
    };
    if (perusteet) {
        $scope.perustelista = Utils.perusteFilter(perusteet);
    }
    var fetch = function (notify) {
        return $q(function (resolve, reject) {
            OpsService.refetchPohja(function (res) {
                $scope.model = res;
                if (notify) {
                    $rootScope.$broadcast("rakenne:updated");
                }
                resolve();
            }, reject);
        });
    };
    var successCb = function (res) {
        return $q(function (resolve, reject) {
            Notifikaatiot.onnistui("tallennettu-ok");
            if ($scope.luonnissa) {
                reject();
                $state.go("root.pohjat.yksi", { pohjaId: res.id }, { reload: true });
            }
            else {
                fetch(true)
                    .then(resolve)["catch"](reject);
            }
        });
    };
    function mapJulkaisukielet() {
        $scope.julkaisukielet = _.zipObject($scope.kielivalinnat, _.map($scope.kielivalinnat, function (kieli) {
            return _.indexOf($scope.model.julkaisukielet, kieli) > -1;
        }));
    }
    $scope.$watch("model.julkaisukielet", mapJulkaisukielet);
    var callbacks = {
        edit: fetch,
        validate: function () {
            return $scope.hasRequiredFields();
        },
        save: function () {
            return $q(function (resolve, reject) {
                $scope.model.julkaisukielet = _($scope.julkaisukielet)
                    .keys()
                    .filter(function (koodi) { return $scope.julkaisukielet[koodi]; })
                    .value();
                var params = $scope.luonnissa
                    ? {}
                    : {
                        opsId: $stateParams.pohjaId
                    };
                var peruste = _.find($scope.perustelista, function (peruste) { return peruste.diaarinumero === $scope.model.perusteenDiaarinumero; });
                OpetussuunnitelmaCRUD.save(params, __assign({}, $scope.model, { rakennePohjasta: peruste.toteutus === 'perusopetus' }), function (res) {
                    successCb(res).then(resolve);
                }, Notifikaatiot.serverCb);
            });
        },
        cancel: fetch,
        notify: function (mode) {
            $scope.editMode = mode;
            if (mode) {
                $scope.haePerusteet();
            }
        }
    };
    Editointikontrollit.registerCallback(callbacks);
    $scope.uusi = {
        cancel: function () {
            $timeout(function () {
                $state.go("root.etusivu");
            });
        },
        create: function () {
            callbacks.save();
        }
    };
    $scope.edit = function () {
        Editointikontrollit.startEditing();
    };
    $scope.haePerusteet = function () {
        if (!($scope.editMode || $scope.luonnissa)) {
            return;
        }
        var isLukio = _.any(["koulutustyyppi_2", "koulutustyyppi_23", "koulutustyyppi_14"], function (i) { return i === $scope.model.koulutustyyppi; });
        var isPerusopetus = "koulutustyyppi_16" === $scope.model.koulutustyyppi;
        var perusteet;
        var yksinkertainen = false;
        if (isLukio) {
            perusteet = EperusteetLukiokoulutus;
        }
        else if (isPerusopetus) {
            perusteet = EperusteetPerusopetus;
        }
        else {
            perusteet = EperusteetValmiitPerusteet;
            yksinkertainen = true;
        }
        perusteet.query({}, function (perusteet) {
            if (yksinkertainen) {
                $scope.perustelista = _(perusteet)
                    .filter(function (p) { return p.koulutustyyppi === $scope.model.koulutustyyppi; })
                    .value();
            }
            else {
                $scope.perustelista = perusteet;
            }
        }, Notifikaatiot.serverCb);
    };
    $scope["delete"] = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-poisto",
            primaryBtn: "poista",
            successCb: function () {
                $scope.model.$delete({}, function () {
                    Notifikaatiot.onnistui("poisto-onnistui");
                    $timeout(function () {
                        $state.go("root.etusivu");
                    });
                }, Notifikaatiot.serverCb);
            }
        })();
    };
});
//# sourceMappingURL=tiedot.js.map