"use strict";
ylopsApp
    .directive("statusbadge", function () {
    var OFFSET = 4;
    return {
        templateUrl: "views/opetussuunnitelmat/directives/statusbadge.html",
        restrict: "EA",
        replace: true,
        scope: {
            status: "=",
            editable: "=?",
            projektiId: "=",
            model: "="
        },
        controller: "StatusbadgeController",
        link: function (scope, element) {
            var el = element.find(".status-name");
            var adjust = function () {
                if (scope.status && scope.status.length > 8) {
                    var spacing = 1 - (scope.status.length - OFFSET) * 0.2;
                    el.css("letter-spacing", spacing + "px");
                }
            };
            scope.$watch("status", adjust);
            adjust();
        }
    };
})
    .controller("StatusbadgeController", function ($scope, $state, OpsinTilanvaihto, OpsinTila, Notifikaatiot, OpetussuunnitelmaOikeudetService) {
    $scope.iconMapping = {
        luonnos: "pencil",
        laadinta: "pencil",
        kommentointi: "comment",
        viimeistely: "certificate",
        kaannos: "book",
        valmis: "thumbs-up",
        julkaistu: "glass",
        poistettu: "folder-open"
    };
    var OPSTILAT = ["luonnos", "valmis", "julkaistu", "poistettu"];
    var POHJATILAT = ["luonnos", "valmis", "poistettu"];
    var getTilat = function (isPohja, current) {
        var tilat = _.without(isPohja ? POHJATILAT : OPSTILAT, current);
        switch (current) {
            case "valmis":
                return isPohja ? ["luonnos", "poistettu"] : tilat;
            case "julkaistu":
                return _.without(tilat, "luonnos");
            default:
                return _.without(tilat, "julkaistu");
        }
    };
    $scope.appliedClasses = function () {
        var classes = { editable: $scope.editable };
        classes[$scope.status] = true;
        return classes;
    };
    $scope.iconClasses = function () { return "glyphicon glyphicon-" + $scope.iconMapping[$scope.status]; };
    $scope.startEditing = function () {
        var isPohja = $scope.model.tyyppi === "pohja";
        if (!OpetussuunnitelmaOikeudetService.onkoOikeudet(isPohja ? "pohja" : "opetussuunnitelma", "tilanvaihto")) {
            return;
        }
        OpsinTilanvaihto.start({
            currentStatus: $scope.status,
            mahdollisetTilat: getTilat(isPohja, $scope.status),
            isPohja: isPohja
        }, function (newStatus) {
            OpsinTila.save($scope.model, newStatus, function (res) {
                Notifikaatiot.onnistui("tallennettu-ok");
                $scope.status = res.tila;
                $state.go($state.current, {}, { reload: true });
            });
        });
    };
});
//# sourceMappingURL=statusbadge.js.map