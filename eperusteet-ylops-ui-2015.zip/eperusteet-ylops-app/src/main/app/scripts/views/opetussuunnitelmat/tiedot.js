"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
ylopsApp.controller("OpetussuunnitelmaTiedotController", function ($scope, Editointikontrollit, $stateParams, $state, $timeout, $q, $rootScope, Api, OpetussuunnitelmaCRUD, Notifikaatiot, OpsService, Utils, KoodistoHaku, PeruskouluHaku, PeruskoulutoimijaHaku, LukiotoimijaHaku, LukioHaku, kunnat, Kieli, OpetussuunnitelmaOikeudetService, Varmistusdialogi) {
    var _this = this;
    function hasLukio() {
        return _.any(["koulutustyyppi_2", "koulutustyyppi_23", "koulutustyyppi_14"], function (i) { return i === $scope.editableModel.koulutustyyppi; });
    }
    function getKoulutustoimijat(kunnat) {
        return __awaiter(this, void 0, void 0, function () {
            var oppilaitostyyppi, toimijat;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        oppilaitostyyppi = [12, 19, 64];
                        if (hasLukio()) {
                            oppilaitostyyppi.push(15);
                        }
                        else if ($scope.editableModel.koulutustyyppi === "koulutustyyppi_999907") {
                            oppilaitostyyppi.push(1, 61);
                        }
                        else if ($scope.editableModel.koulutustyyppi === "koulutustyyppi_17") {
                            oppilaitostyyppi.push(11, 15, 21, 22, 23, 24, 63);
                        }
                        else {
                            oppilaitostyyppi.push(11);
                        }
                        return [4, Api.all("ulkopuoliset/organisaatiot/koulutustoimijat/").getList({
                                kunta: kunnat,
                                oppilaitostyyppi: oppilaitostyyppi
                            })];
                    case 1:
                        toimijat = _a.sent();
                        return [2, toimijat.plain()];
                }
            });
        });
    }
    $scope.kouluvalinta = false;
    $scope.kielivalinnat = [];
    $scope.luonnissa = $stateParams.id === "uusi";
    $scope.editableModel = _.clone($scope.model);
    if ($scope.luonnissa) {
        OpetussuunnitelmaCRUD.query({ tyyppi: "pohja", tila: "valmis" }, function (pohjat) {
            $scope.pohjat = Utils.opsFilter(pohjat);
        });
        $scope.editableModel.julkaisukielet = [_.first($scope.kielivalinnat)];
        $scope.editableModel._pohja = $stateParams.pohjaId === "" ? null : $stateParams.pohjaId;
        $scope.editVuosiluokkakokonaisuudet = true;
    }
    else {
        $scope.editVuosiluokkakokonaisuudet =
            OpetussuunnitelmaOikeudetService.onkoOikeudet("pohja", "luonti", true) ||
                OpetussuunnitelmaOikeudetService.onkoOikeudet("opetussuunnitelma", "tilanvaihto", true);
    }
    $scope.$$isOps = true;
    $scope.editMode = false;
    $scope.loading = false;
    $scope.kuntalista = [];
    $scope.koulutoimijalista = [];
    $scope.koululista = [];
    $scope.eiKoulujaVaroitus = false;
    $scope.ryhmalista = null;
    $scope.nimiOrder = function (vlk) {
        return Utils.sort(vlk.vuosiluokkakokonaisuus);
    };
    $scope.model.nimi.$$validointi = Kieli.validoi($scope.model.nimi);
    var loading = false;
    $scope.vaihdaKouluvalinta = function (value) { return __awaiter(_this, void 0, void 0, function () {
        var ryhmalista;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    $scope.editableModel.kunnat = [];
                    $scope.editableModel.koulutoimijat = [];
                    $scope.editableModel.koulut = [];
                    if (!value) return [3, 2];
                    if (!(!$scope.ryhmalista && !loading)) return [3, 2];
                    loading = true;
                    return [4, Api.all("ulkopuoliset/organisaatioryhmat").getList()];
                case 1:
                    ryhmalista = _a.sent();
                    $scope.ryhmalista = ryhmalista;
                    _a.label = 2;
                case 2:
                    $scope.kouluvalinta = value;
                    return [2];
            }
        });
    }); };
    $scope.sallitutKoulutustyypit = [
        "koulutustyyppi_2",
        "koulutustyyppi_6",
        "koulutustyyppi_14",
        "koulutustyyppi_15",
        "koulutustyyppi_16",
        "koulutustyyppi_999907",
        "koulutustyyppi_17",
        "koulutustyyppi_20",
        "koulutustyyppi_22",
        "koulutustyyppi_23"
    ];
    $scope.dateOptions = {
        "year-format": "yy",
        "starting-day": 1
    };
    $scope.format = "d.M.yyyy";
    $scope.kalenteriTilat = {};
    $scope.open = function ($event) {
        $event.stopPropagation();
        $event.preventDefault();
        $scope.kalenteriTilat.paatospaivamaaraButton = true;
    };
    $scope.hasRequiredFields = function () {
        var model = $scope.editableModel;
        var nimiOk = Utils.hasLocalizedText(model.nimi);
        var organisaatiotOk = !$scope.luonnissa
            || (model.kunnat && model.kunnat.length > 0
                && model.koulutoimijat && model.koulutoimijat.length > 0);
        var julkaisukieletOk = _.any(_.values($scope.julkaisukielet));
        var vlkOk = (!$scope.luonnissa && !$scope.editVuosiluokkakokonaisuudet) ||
            model.koulutustyyppi !== "koulutustyyppi_16" ||
            _(model.vuosiluokkakokonaisuudet)
                .filter({ valittu: true })
                .size() > 0;
        if (model.koulutustyyppi === "koulutustyyppi_999907") {
            return nimiOk;
        }
        else {
            return nimiOk && organisaatiotOk && julkaisukieletOk && vlkOk;
        }
    };
    function mapKunnat(lista) {
        return _(lista)
            .map(function (kunta) {
            return {
                koodiUri: kunta.koodiUri,
                koodiArvo: kunta.koodiArvo,
                nimi: _(kunta.metadata)
                    .indexBy(function (item) {
                    return item.kieli.toLowerCase();
                })
                    .mapValues("nimi")
                    .value()
            };
        })
            .sortBy(Utils.sort)
            .value();
    }
    function filterOrganisaatio(tyyppi) {
        return function (organisaatiot) {
            return _.filter(organisaatiot, function (org) {
                return _.includes(org.tyypit, tyyppi);
            });
        };
    }
    var filterKoulutustoimija = filterOrganisaatio("Koulutustoimija");
    var filterOppilaitos = filterOrganisaatio("Oppilaitos");
    var filterRyhma = filterOrganisaatio("Ryhma");
    if (kunnat) {
        $scope.kuntalista = mapKunnat(kunnat);
    }
    if ($scope.model.organisaatiot) {
        $scope.model.koulutoimijat = filterKoulutustoimija($scope.model.organisaatiot);
        $scope.model.koulut = filterOppilaitos($scope.model.organisaatiot);
        $scope.model.ryhmat = filterRyhma($scope.model.organisaatiot);
    }
    function isValidKielivalinta(chosen, options) {
        return _.all(chosen, function (lang) {
            return _.contains(options, lang);
        });
    }
    function asetaKieletJaVlk(ops) {
        $scope.opsvuosiluokkakokonaisuudet = ops.vuosiluokkakokonaisuudet;
        $scope.editableModel.vuosiluokkakokonaisuudet = ops.vuosiluokkakokonaisuudet;
        $scope.kielivalinnat = Kieli.sortKielet(ops.julkaisukielet);
        if (_.isEmpty($scope.editableModel.julkaisukielet) ||
            !isValidKielivalinta($scope.editableModel.julkaisukielet, $scope.kielivalinnat)) {
            $scope.editableModel.julkaisukielet = [_.first($scope.kielivalinnat)];
        }
        mapJulkaisukielet();
    }
    if ($scope.luonnissa) {
        if ($scope.editableModel._pohja) {
            (function () {
                return __awaiter(this, void 0, void 0, function () {
                    var res, ex_1;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                _a.trys.push([0, 2, , 3]);
                                return [4, OpetussuunnitelmaCRUD.get({ opsId: $scope.editableModel._pohja }).$promise];
                            case 1:
                                res = _a.sent();
                                $scope.$$pohja = res;
                                $scope.editableModel.$$pohja = res;
                                $scope.pohjanNimi = res.nimi;
                                $scope.editableModel.kunnat = res.kunnat;
                                $scope.editableModel.koulutoimijat = filterKoulutustoimija(res.organisaatiot);
                                $scope.editableModel.koulut = filterOppilaitos(res.organisaatiot);
                                $scope.editableModel.koulutustyyppi = res.koulutustyyppi;
                                asetaKieletJaVlk(res);
                                return [3, 3];
                            case 2:
                                ex_1 = _a.sent();
                                Notifikaatiot.serverCb(ex_1);
                                return [3, 3];
                            case 3: return [2];
                        }
                    });
                });
            })();
        }
        else {
            $scope.$watch("editableModel.$$pohja", function () {
                if ($scope.editableModel.$$pohja) {
                    OpetussuunnitelmaCRUD.get({ opsId: $scope.editableModel.$$pohja.id }, function (pohja) {
                        $scope.editableModel.koulutustyyppi = pohja.koulutustyyppi;
                        $scope.editableModel._pohja = "" + pohja.id;
                        asetaKieletJaVlk(pohja);
                    });
                }
            });
        }
    }
    else {
        $scope.$watch("editableModel.$$pohja", function () {
            if ($scope.editableModel.pohja) {
                OpetussuunnitelmaCRUD.get({ opsId: $scope.editableModel.pohja.id }, function (pohja) {
                    $scope.editableModel.koulutustyyppi = pohja.koulutustyyppi;
                    $scope.editableModel._pohja = "" + pohja.id;
                    asetaKieletJaVlk(pohja);
                });
            }
            else {
                asetaKieletJaVlk($scope.editableModel);
            }
        });
    }
    $scope.$watch("editableModel.koulutustyyppi", function (value) {
        if ($scope.luonnissa) {
            $timeout(function () {
                $scope.$apply(function () {
                    $scope.model.kunnat = [];
                    $scope.model.koulutoimijat = [];
                    $scope.model.koulut = [];
                    $scope.editableModel.kunnat = [];
                    $scope.editableModel.koulutoimijat = [];
                    $scope.editableModel.koulut = [];
                    $scope.koulutoimijalista = [];
                    $scope.koululista = [];
                    $scope.haeKunnat();
                });
            });
        }
    });
    $scope.kieliOrderFn = Kieli.orderFn;
    function fixTimefield(field) {
        if (typeof $scope.editableModel[field] === "number") {
            $scope.editableModel[field] = new Date($scope.editableModel[field]);
        }
    }
    var fetch = function (notify) {
        return $q(function (resolve, reject) {
            OpsService.refetch(function (res) {
                $scope.model = res;
                $scope.editableModel = res;
                if ($scope.model.pohja) {
                    $scope.kielivalinnat = Kieli.sortKielet($scope.model.pohja.julkaisukielet);
                }
                if (_.size(res.vuosiluokkakokonaisuudet) > 0) {
                    var vuosiluokkakokonaisuudet = _(res.vuosiluokkakokonaisuudet)
                        .each(function (v) {
                        v.valittu = true;
                    })
                        .concat($scope.opsvuosiluokkakokonaisuudet)
                        .value();
                    vuosiluokkakokonaisuudet = _.chain(vuosiluokkakokonaisuudet)
                        .filter('vuosiluokkakokonaisuus')
                        .uniq('vuosiluokkakokonaisuus._tunniste')
                        .value();
                    $scope.editableModel.vuosiluokkakokonaisuudet = vuosiluokkakokonaisuudet;
                }
                $scope.editableModel.koulutoimijat = filterKoulutustoimija(res.organisaatiot);
                $scope.editableModel.koulut = filterOppilaitos(res.organisaatiot);
                $scope.editableModel.ryhmat = filterRyhma(res.organisaatiot);
                fixTimefield("paatospaivamaara");
                if (notify) {
                    $rootScope.$broadcast("rakenne:updated");
                }
                $scope.loading = false;
                resolve();
            });
        });
    };
    var successCb = function (res) {
        Notifikaatiot.onnistui("tallennettu-ok");
        if ($scope.luonnissa) {
            $state.go("root.opetussuunnitelmat.yksi.sisalto", { id: res.id }, { reload: true });
            return $q.reject();
        }
        else {
            return fetch(true);
        }
    };
    var callbacks = {
        edit: function () {
            $scope.loading = true;
            return fetch();
        },
        asyncValidate: function (save) {
            var muokattuVuosiluokkakokonaisuuksia = _.some(_.pluck($scope.editableModel.vuosiluokkakokonaisuudet, "muutettu"));
            if (!$scope.luonnissa && muokattuVuosiluokkakokonaisuuksia) {
                Varmistusdialogi.dialogi({
                    otsikko: "vahvista-vuosiluokkakokonaisuudet-muokkaus-otsikko",
                    teksti: "vahvista-vuosiluokkakokonaisuudet-muokkaus-teksti"
                })(save);
            }
            else {
                save();
            }
            return $q.when();
        },
        validate: function () {
            return $scope.hasRequiredFields();
        },
        save: function () {
            return $q(function (resolve, reject) {
                $scope.editableModel.julkaisukielet = _($scope.julkaisukielet)
                    .keys()
                    .filter(function (koodi) {
                    return $scope.julkaisukielet[koodi];
                })
                    .value();
                if (!$scope.kouluvalinta) {
                    $scope.editableModel.organisaatiot = $scope.editableModel.koulutoimijat.concat($scope.editableModel.koulut);
                }
                else {
                    $scope.editableModel.organisaatiot = [
                        $scope.editableModel.organisaatiot
                    ];
                }
                delete $scope.editableModel.tekstit;
                delete $scope.editableModel.oppiaineet;
                $scope.editableModel.vuosiluokkakokonaisuudet = _.remove($scope.editableModel.vuosiluokkakokonaisuudet, { valittu: true });
                if ($scope.luonnissa) {
                    OpetussuunnitelmaCRUD.save({}, $scope.editableModel, function (res) {
                        successCb(res).then(resolve);
                    }, function (err) {
                        $scope.savingDisabled = false;
                        Notifikaatiot.serverCb(err);
                    });
                }
                else {
                    OpetussuunnitelmaCRUD.save({
                        opsId: $scope.editableModel.id
                    }, $scope.editableModel, function (res) {
                        successCb(res).then(resolve);
                    }, function (err) {
                        $scope.savingDisabled = false;
                        Notifikaatiot.serverCb(err);
                    });
                }
            });
        },
        cancel: function () {
            return fetch();
        },
        notify: function (mode) {
            $scope.editMode = mode;
            if (mode) {
                $scope.haeKunnat();
                $scope.haeKoulutoimijat();
                $scope.haeKoulut();
            }
        }
    };
    Editointikontrollit.registerCallback(callbacks);
    $scope.toggle = function (vkl) {
        vkl.muutettu = vkl.muutettu === undefined ? true : !vkl.muutettu;
    };
    $scope.uusi = {
        cancel: function () {
            $timeout(function () {
                $state.go("root.etusivu");
            });
        },
        create: function () {
            $scope.savingDisabled = true;
            callbacks.save();
        }
    };
    $scope.edit = function () {
        Editointikontrollit.startEditing();
    };
    $scope.haeKunnat = function () {
        return __awaiter(this, void 0, void 0, function () {
            var kunnat_1, ex_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!($scope.editMode || $scope.luonnissa)) {
                            return [2];
                        }
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4, KoodistoHaku.get({ koodistoUri: "kunta" }).$promise];
                    case 2:
                        kunnat_1 = _a.sent();
                        $scope.kuntalista = mapKunnat(kunnat_1);
                        return [3, 4];
                    case 3:
                        ex_2 = _a.sent();
                        Notifikaatiot.serverCb(ex_2);
                        return [3, 4];
                    case 4: return [2];
                }
            });
        });
    };
    function updateKouluVaroitus() {
        $scope.eiKoulujaVaroitus =
            _.isArray($scope.editableModel.koulutoimijat) &&
                $scope.editableModel.koulutoimijat.length === 1 &&
                _.isArray($scope.koululista) &&
                $scope.koululista.length === 0 &&
                $scope.koulut && $scope.koulut.length === 0;
    }
    function updateKoulutoimijaVaroitus() {
        $scope.eiKoulutoimijoitaVaroitus =
            _.isArray($scope.editableModel.kunnat) &&
                $scope.editableModel.kunnat.length === 1 &&
                _.isArray($scope.koulutoimijat) &&
                $scope.koulutoimijat.length === 0;
    }
    $scope.$watch("editableModel.kunnat", function () {
        $scope.haeKoulutoimijat();
    });
    $scope.$watch("editableModel.koulutoimijat", function () {
        $scope.haeKoulut();
        updateKoulutoimijaVaroitus();
    });
    $scope.$watch("koululista", function () {
        updateKouluVaroitus();
    });
    function mapJulkaisukielet() {
        $scope.julkaisukielet = _.zipObject($scope.kielivalinnat, _.map($scope.kielivalinnat, function (kieli) {
            return _.indexOf($scope.editableModel.julkaisukielet, kieli) > -1;
        }));
    }
    $scope.$watch("editableModel.julkaisukielet", mapJulkaisukielet);
    $scope.haeKoulut = function () {
        var koulutoimijat = $scope.editableModel.koulutoimijat;
        if (!($scope.editMode || $scope.luonnissa) || !koulutoimijat) {
            return;
        }
        if (koulutoimijat.length === 0) {
            $scope.loadingKoulut = false;
            $scope.editableModel.koulut = [];
        }
        else if (koulutoimijat.length === 1) {
            var koulutoimija_1 = koulutoimijat[0];
            $timeout(function () {
                $scope.koululista = _(koulutoimija_1.children)
                    .map(function (koulu) { return _.pick(koulu, ["oid", "nimi", "tyypit"]); })
                    .sortBy(Utils.sort)
                    .value();
            });
        }
        else {
            $scope.loadingKoulut = false;
            $scope.editableModel.koulut = [];
            $scope.koululista = [];
        }
    };
    $scope.haeKoulutoimijat = function () {
        return __awaiter(this, void 0, void 0, function () {
            var kunnat, kuntaUrit, koulutoimijat;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        $scope.loadingKoulutoimijat = true;
                        kunnat = $scope.editableModel.kunnat;
                        if (!(kunnat && ($scope.editMode || $scope.luonnissa))) return [3, 3];
                        if (!(kunnat.length === 0)) return [3, 1];
                        $scope.editableModel.koulutoimijat = [];
                        $scope.editableModel.koulut = [];
                        return [3, 3];
                    case 1:
                        kuntaUrit = _.map(kunnat, "koodiUri");
                        return [4, getKoulutustoimijat(kuntaUrit)];
                    case 2:
                        koulutoimijat = _a.sent();
                        $scope.koulutoimijalista = koulutoimijat;
                        $scope.editableModel.koulutoimijat = _.filter($scope.editableModel.koulutoimijat, function (koulutoimija) {
                            return _.includes(_.map($scope.koulutoimijalista, "oid"), koulutoimija.oid);
                        });
                        _a.label = 3;
                    case 3:
                        $scope.loadingKoulutoimijat = false;
                        return [2];
                }
            });
        });
    };
});
//# sourceMappingURL=tiedot.js.map