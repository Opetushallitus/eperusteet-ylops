"use strict";
ylopsApp
    .controller("LukioOppiaineetController", function ($scope, $state, $modal, $stateParams, $q, $timeout, Editointikontrollit, LukioTreeUtils, LukioOpetussuunnitelmaService, Notifikaatiot, rakenne) {
    $scope.root = LukioTreeUtils.buildTree(rakenne);
    $scope.editMode = false;
    $scope.haku = "";
    $scope.rakenne = rakenne;
    $scope.hae = function () {
        $timeout(function () {
            LukioTreeUtils.search($scope.root, $scope.haku);
        });
    };
    $scope.canAddFromTarjonta = function () { return $scope.rakenne && !_.isEmpty($scope.rakenne.pohjanTarjonta); };
    $scope.addOppiaine = function () { return $state.go("root.opetussuunnitelmat.lukio.opetus.uusioppiaine"); };
    $scope.addTarjonnasta = function (pohjanOppiaine) {
        $modal.open({
            templateUrl: "views/opetussuunnitelmat/modals/lukioAbstraktiOppiaineModaali.html",
            controller: "LukioTuoAbstraktiOppiaineController",
            size: "lg",
            resolve: {
                opsId: _.constant($stateParams.id),
                valittu: _.constant(pohjanOppiaine)
            }
        })
            .result.then(function (res) {
            $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                id: $stateParams.id,
                oppiaineId: res.id
            });
        }, function () { });
    };
    $scope.toEditMode = function () {
        $scope.editMode = true;
        Editointikontrollit.startEditing();
    };
    Editointikontrollit.registerCallback({
        doNotShowMandatoryMessage: true,
        validate: function () {
            return true;
        },
        edit: function () { return LukioOpetussuunnitelmaService.lukitseRakenne(); },
        cancel: function () { return $q(function (resolve) {
            LukioOpetussuunnitelmaService.vapautaRakenne().then(function () {
                LukioOpetussuunnitelmaService.getRakenne($stateParams.id)
                    .then(function (rakenne) {
                    $scope.rakenne = rakenne;
                    $scope.root = LukioTreeUtils.buildTree(rakenne);
                    $scope.editMode = false;
                    resolve();
                });
            });
        }); },
        save: function (kommentti) {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.updateOppiaineKurssiStructure($scope.root, kommentti).then(function () {
                    Notifikaatiot.onnistui("lukio-puun-muokkaus-onnistui");
                    LukioOpetussuunnitelmaService.vapautaRakenne().then(function () {
                        $scope.editMode = false;
                        resolve();
                    });
                });
            });
        }
    });
})
    .service("LukioControllerHelpers", function ($rootScope, Koodisto, MuokkausUtils, Kieli, Kaanna, $log) {
    var mapKoodiArvo = function (and) { return function (obj, koodisto) {
        MuokkausUtils.nestedSet(obj, "koodiUri", ",", koodisto.koodiUri);
        MuokkausUtils.nestedSet(obj, "koodiArvo", ",", koodisto.koodiArvo);
        MuokkausUtils.nestedSet(obj, "nimi", ",", koodisto.nimi);
        if (and) {
            and(koodisto);
        }
    }; };
    var openKoodisto = function (obj, koodisto, map) { return function () {
        Koodisto.modaali(function (koodisto) {
            map(obj, _.cloneDeep(koodisto));
            $rootScope.$broadcast("notifyCKEditor");
        }, {
            tyyppi: function () {
                return koodisto;
            },
            ylarelaatioTyyppi: function () {
                return "";
            }
        })();
    }; };
    var kielella = function (val) {
        var loc = {};
        loc[Kieli.getSisaltokieli()] = val;
        return loc;
    };
    var prefixFunc = function (func) {
        if (!(func instanceof Function)) {
            var orig = func;
            return function (id) { return orig + id; };
        }
        return func;
    };
    var tekstit = function (idt, label, container) { return function (obj) {
        var labelFunc = prefixFunc(label);
        if (container) {
            obj = container(obj);
        }
        var os = _(idt)
            .map(function (id) {
            return { id: id, label: labelFunc(id), obj: obj ? obj[id] : null };
        })
            .value(), byId = _(os)
            .indexBy(function (o) { return o.id; })
            .value();
        return {
            osat: os,
            isAddAvailable: function () { return _.any(os, function (o) { return !o.obj; }); },
            isEmpty: function () { return !_.any(os, function (o) { return o.obj; }); },
            addOsa: function (id) {
                var newOsa = kielella("");
                obj[id] = newOsa;
                byId[id].obj = newOsa;
                $rootScope.$broadcast("notifyCKEditor");
                $rootScope.$broadcast("enableEditing");
            },
            removeOsa: function (id) {
                obj[id] = null;
                byId[id].obj = null;
                $rootScope.$broadcast("notifyCKEditor");
            }
        };
    }; };
    var osat = function (idt, label, container) { return function (obj) {
        var labelFunc = prefixFunc(label);
        if (container) {
            obj = container(obj);
        }
        var os = _(idt)
            .map(function (id) {
            return { id: id, obj: obj ? obj[id] : null, label: labelFunc(id) };
        })
            .value(), byId = _(os)
            .indexBy(function (o) { return o.id; })
            .value();
        return {
            osat: os,
            isAddAvailable: function () { return _.any(os, function (o) { return !o.obj; }); },
            isEmpty: function () { return !_.any(os, function (o) { return o.obj; }); },
            addOsa: function (id) {
                var newOsa = {
                    otsikko: kielella(Kaanna.kaanna(labelFunc(id))),
                    teksti: kielella("")
                };
                obj[id] = newOsa;
                byId[id].obj = newOsa;
                $rootScope.$broadcast("notifyCKEditor");
                $rootScope.$broadcast("enableEditing");
            },
            removeOsa: function (id) {
                obj[id] = null;
                byId[id].obj = null;
                $rootScope.$broadcast("notifyCKEditor");
            }
        };
    }; };
    var valtakunnallisetKurssiTyypit = [
        "VALTAKUNNALLINEN_PAKOLLINEN",
        "VALTAKUNNALLINEN_SYVENTAVA",
        "VALTAKUNNALLINEN_SOVELTAVA"
    ];
    var paikallisetKurssiTyypit = ["PAIKALLINEN_SYVENTAVA", "PAIKALLINEN_SOVELTAVA"];
    var kaikkiKurssiTyypit = _.union(valtakunnallisetKurssiTyypit, paikallisetKurssiTyypit);
    return {
        openOppiaineKoodisto: function (obj) {
            return openKoodisto(obj, "oppiaineetyleissivistava2", mapKoodiArvo());
        },
        openKurssiKoodisto: function (obj) {
            return openKoodisto(obj, "lukionkurssit", mapKoodiArvo(function (koodi) {
                obj.lokalisoituKoodi = {};
                obj.lokalisoituKoodi[Kieli.getSisaltokieli()] = koodi.koodiArvo;
            }));
        },
        kielella: kielella,
        openOppiaineKieliKoodisto: function (obj, and) {
            return openKoodisto(obj, "lukiokielitarjonta", function (o, koodisto) {
                MuokkausUtils.nestedSet(o, "kieliKoodiUri", ",", koodisto.koodiUri);
                MuokkausUtils.nestedSet(obj, "kieliKoodiArvo", ",", koodisto.koodiArvo);
                MuokkausUtils.nestedSet(obj, "kieli", ",", koodisto.nimi);
                if (and) {
                    and(koodisto);
                }
            });
        },
        valtakunnallisetKurssiTyypit: function () { return _.clone(valtakunnallisetKurssiTyypit); },
        paikallisetKurssiTyypit: function () { return _.clone(paikallisetKurssiTyypit); },
        kaikkiKurssiTyypit: function () { return _.clone(kaikkiKurssiTyypit); },
        kurssiTyyppiKuvausTekstit: tekstit(kaikkiKurssiTyypit, function (id) { return "lukio-kurssi-tyyppi-otsikko-" + id.toLowerCase(); }, function (obj) { return obj.kurssiTyyppiKuvaukset; }),
        muokattavatOppiaineOsat: osat(["tehtava", "tavoitteet", "arviointi"], "oppiaine-osa-"),
        muokattavatKurssiOsat: osat(["tavoitteet", "keskeinenSisalto", "tavoitteetJaKeskeinenSisalto"], "kurssi-osa-")
    };
})
    .controller("LukioOppiaineController", function ($scope, $q, $stateParams, $state, $timeout, OpsService, LukioOpetussuunnitelmaService, Kaanna, $log, $modal, Editointikontrollit, LukioControllerHelpers, Varmistusdialogi, Notifikaatiot, Lukko) {
    $scope.oppiaine = null;
    $scope.editMode = false;
    $scope.kurssiKuvauksetVisible = false;
    $scope.rootOps = true;
    $scope.connected = function () {
        return $scope.oppiaine &&
            !$scope.oppiaine.oma &&
            !$scope.rootOps &&
            $scope.oppiaine.maariteltyPohjassa &&
            !$scope.oppiaine.oppiaineId;
    };
    $scope.isReconnectable = function () {
        return $scope.oppiaine &&
            $scope.oppiaine.oma &&
            !$scope.rootOps &&
            $scope.oppiaine.maariteltyPohjassa &&
            !$scope.oppiaine.oppiaineId;
    };
    $scope.isEditable = function () { return $scope.oppiaine && $scope.oppiaine.oma; };
    $scope.isDeletable = function () {
        return $scope.oppiaine &&
            $scope.oppiaine.oma &&
            (!$scope.oppiaine.maariteltyPohjassa ||
                (!$scope.oppiaine.oppiaineId && $scope.oppiaine.abstrakti) ||
                ($scope.oppiaine.oppiaineId && !$scope.oppiaine.abstrakti));
    };
    $scope.canAddOppimaara = function () { return $scope.oppiaine && $scope.oppiaine.koosteinen && $scope.oppiaine.oma; };
    $scope.canAddFromTarjonta = function () {
        return $scope.oppiaine &&
            $scope.oppiaine.koosteinen &&
            $scope.oppiaine.oma &&
            !_.isEmpty($scope.oppiaine.pohjanTarjonta);
    };
    var noOwnCourses = [
        "oppiaineetyleissivistava2_tvk",
        "oppiaineetyleissivistava2_ld",
        "oppiaineetyleissivistava2_to"
    ];
    $scope.canAddKurssi = function () {
        return !$scope.editing &&
            $scope.oppiaine &&
            !$scope.oppiaine.koosteinen &&
            !_.any(noOwnCourses, function (k) { return k === $scope.oppiaine.koodiUri; });
    };
    $scope.tarjottavaTyyppi = function () {
        if (!$scope.canAddFromTarjonta()) {
            return null;
        }
        return OpsService.oppiaineIsKieli($scope.oppiaine)
            ? "kieli"
            : $scope.oppiaine.koodiArvo == "KT" ? "uskonto" : "tuntematon";
    };
    $scope.isKurssiDeletable = function (kurssi) {
        return (kurssi.tyyppi === "VALTAKUNNALLINEN_SOVELTAVA" ||
            _.any(LukioControllerHelpers.paikallisetKurssiTyypit(), function (t) { return kurssi.tyyppi == t; }));
    };
    $scope.removeKurssi = function ($event, kurssi) {
        $event.preventDefault();
        $event.stopPropagation();
        LukioOpetussuunnitelmaService.lukitseKurssi(kurssi.id).then(function () {
            Varmistusdialogi.dialogi({
                otsikko: "varmista-poista-kurssi",
                primaryBtn: "poista-kurssi",
                failureCb: function () { return LukioOpetussuunnitelmaService.vapautaKurssi(kurssi.id); },
                successCb: function () {
                    return LukioOpetussuunnitelmaService.removeKurssi(kurssi.id, $stateParams.id).then(function () {
                        Notifikaatiot.onnistui("kurssin-poisto-onnistui");
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                                id: $stateParams.id,
                                oppiaineId: $stateParams.oppiaineId
                            }, { reload: true, notify: true });
                        });
                    });
                }
            })();
        });
    };
    $scope.isKurssiDeletable = function (kurssi) {
        return (kurssi.tyyppi === "VALTAKUNNALLINEN_SOVELTAVA" ||
            _.any(LukioControllerHelpers.paikallisetKurssiTyypit(), function (t) { return kurssi.tyyppi == t; }));
    };
    $scope.removeKurssi = function ($event, kurssi) {
        $event.preventDefault();
        $event.stopPropagation();
        LukioOpetussuunnitelmaService.lukitseKurssi(kurssi.id).then(function () {
            Varmistusdialogi.dialogi({
                otsikko: "varmista-poista-kurssi",
                primaryBtn: "poista-kurssi",
                failureCb: function () { return LukioOpetussuunnitelmaService.vapautaKurssi(kurssi.id); },
                successCb: function () {
                    return LukioOpetussuunnitelmaService.removeKurssi(kurssi.id, $stateParams.id).then(function () {
                        Notifikaatiot.onnistui("kurssin-poisto-onnistui");
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                                id: $stateParams.id,
                                oppiaineId: $stateParams.oppiaineId
                            }, { reload: true, notify: true });
                        });
                    });
                }
            })();
        });
    };
    LukioOpetussuunnitelmaService.getOppiaine($stateParams.oppiaineId).then(function (oa) {
        $scope.oppiaine = oa;
        $scope.muokattavatOsat = LukioControllerHelpers.muokattavatOppiaineOsat(oa);
        $scope.openKoodisto = LukioControllerHelpers.openOppiaineKoodisto($scope.oppiaine);
        $scope.kurssiTyyppiKuvaukset = LukioControllerHelpers.kurssiTyyppiKuvausTekstit($scope.oppiaine);
    });
    LukioOpetussuunnitelmaService.getRakenne().then(function (r) { return ($scope.rootOps = r.root); });
    $scope.openKurssi = function (kurssi) {
        $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
            id: $stateParams.id,
            oppiaineId: $stateParams.oppiaineId,
            kurssiId: kurssi.id
        });
    };
    $scope.valtakunnallisetKurssiTyypit = _.map(LukioControllerHelpers.valtakunnallisetKurssiTyypit(), function (tyyppi) { return ({
        key: tyyppi,
        tyyppi: tyyppi.split("_")[1].toLowerCase()
    }); });
    $scope.paikallisetKurssiTyypit = _.map(LukioControllerHelpers.paikallisetKurssiTyypit(), function (tyyppi) { return ({
        key: tyyppi,
        tyyppi: tyyppi.split("_")[1].toLowerCase()
    }); });
    $scope.kuvauksetIsEmpty = function (tyypit) {
        return !_.any(tyypit, function (t) {
            return (t &&
                $scope.oppiaine &&
                ($scope.oppiaine.kurssiTyyppiKuvaukset[t.key] ||
                    ($scope.oppiaine.perusteen && $scope.oppiaine.perusteen.kurssiTyyppiKuvaukset[t.key])));
        });
    };
    $scope.deleteOppiaine = function () {
        var maara = $scope.oppiaine.oppiaineId != null;
        Varmistusdialogi.dialogi({
            otsikko: maara ? "varmista-poista-oppimaara" : "varmista-poista-oppiaine",
            primaryBtn: "poista",
            successCb: function () {
                return LukioOpetussuunnitelmaService.deleteOppiaine($stateParams.oppiaineId).then(function () {
                    if (maara) {
                        Notifikaatiot.onnistui("oppimaaran-poisto-onnistui");
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                                id: $stateParams.id,
                                oppiaineId: $scope.oppiaine.oppiaineId
                            }, { reload: true, notify: true });
                        });
                    }
                    else {
                        Notifikaatiot.onnistui("oppiaineen-poisto-onnistui");
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaineet", {
                                id: $stateParams.id
                            });
                        });
                    }
                });
            }
        })();
    };
    var palautaYlempi = function () {
        LukioOpetussuunnitelmaService.lukitseOppiaine($stateParams.oppiaineId).then(function () {
            return LukioOpetussuunnitelmaService.palautaYlempaan($stateParams.oppiaineId).then(function (res) {
                Notifikaatiot.onnistui("yhteyden-palautus-onnistui");
                $timeout(function () {
                    return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                        id: $stateParams.id,
                        oppiaineId: res.id
                    }, { reload: true, notify: true });
                });
            });
        });
    };
    $scope.connectOppiaine = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-palauta-yhteys",
            primaryBtn: "palauta-yhteys",
            successCb: function () { return palautaYlempi(); }
        })();
    };
    var cloneOppiaine = function () {
        LukioOpetussuunnitelmaService.kloonaaOppiaineMuokattavaksi($stateParams.oppiaineId).then(function (res) {
            Notifikaatiot.onnistui("yhteyden-katkaisu-onnistui");
            $timeout(function () {
                return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                    id: $stateParams.id,
                    oppiaineId: res.id
                }, { reload: true, notify: true });
            });
        });
    };
    $scope.disconnectOppiaine = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-katkaise-yhteys",
            primaryBtn: "katkaise-yhteys",
            successCb: function () { return cloneOppiaine(); }
        })();
    };
    $scope.addOppimaara = function () {
        $state.go("root.opetussuunnitelmat.lukio.opetus.uusioppiaine", {
            id: $stateParams.id,
            parentOppiaineId: $stateParams.oppiaineId
        }, { reload: true, notify: true });
    };
    $scope.addTarjonnasta = function (pohjanOppiaine) {
        $modal
            .open({
            templateUrl: "views/opetussuunnitelmat/modals/lukioKieliTarjontaModaali.html",
            controller: "LukioKielitarjontaModalController",
            size: "lg",
            resolve: {
                opsId: _.constant($stateParams.id),
                oppiaine: _.constant($scope.oppiaine),
                valittu: _.constant(pohjanOppiaine)
            }
        })
            .result.then(function (res) {
            $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                id: $stateParams.id,
                oppiaineId: res.id
            });
        }, function () { });
    };
    $scope.lisaaKurssi = function () {
        $state.go("root.opetussuunnitelmat.lukio.opetus.uusikurssi", {
            id: $stateParams.id,
            oppiaineId: $stateParams.oppiaineId
        });
    };
    Editointikontrollit.registerCallback({
        validate: function () {
            return $scope.oppiaine.koodiArvo && Kaanna.kaanna($scope.oppiaine.nimi) != null;
        },
        edit: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.lukitseOppiaine($stateParams.oppiaineId).then(function () {
                    $scope.editingOld = true;
                    resolve();
                });
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.vapautaOppiaine($stateParams.oppiaineId).then(function () {
                    $scope.editMode = false;
                    resolve();
                });
            });
        },
        save: function () {
            return $q(function (resolve) {
                $scope.oppiaine.oppiaineId = $scope.oppiaine.id;
                LukioOpetussuunnitelmaService.updateOppiaine($scope.oppiaine).then(function () {
                    LukioOpetussuunnitelmaService.vapautaOppiaine($scope.oppiaine.id)
                        .then(function () {
                        $scope.editMode = false;
                        resolve();
                    })
                        .then($state.reload);
                });
            });
        }
    });
    $scope.toEditMode = function () {
        $scope.editMode = true;
        Editointikontrollit.startEditing();
    };
})
    .controller("LuoLukioOppiaineController", function ($scope, $q, $stateParams, $state, LukioOpetussuunnitelmaService, Kaanna, $log, Editointikontrollit, LukioControllerHelpers) {
    $scope.oppiaine = {
        nimi: {},
        kuvaus: {},
        koosteinen: false,
        oppiaineId: $stateParams.parentOppiaineId ? $stateParams.parentOppiaineId : null,
        kurssiTyyppiKuvaukset: {}
    };
    $scope.isEditable = function () { return true; };
    $scope.editMode = true;
    $scope.muokattavatOsat = LukioControllerHelpers.muokattavatOppiaineOsat($scope.oppiaine);
    $scope.kurssiTyyppiKuvaukset = LukioControllerHelpers.kurssiTyyppiKuvausTekstit($scope.oppiaine);
    $scope.removeKurssiTyyppiKuvaus = function (tyyppi) {
        delete $scope.oppiaine.kurssiTyyppiKuvaukset[tyyppi];
    };
    $scope.addKurssiTyyppiKuvaus = function (tyyppi) {
        $scope.oppiaine.kurssiTyyppiKuvaukset[tyyppi] = LukioControllerHelpers.kielella("");
    };
    Editointikontrollit.registerCallback({
        validate: function () {
            return $scope.oppiaine.koodiArvo && Kaanna.kaanna($scope.oppiaine.nimi) != null;
        },
        edit: function () {
            return $q(function (resolve) {
                resolve();
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                resolve();
                $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaineet");
            });
        },
        save: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.saveOppiaine($scope.oppiaine).then(function (ref) {
                    resolve();
                    $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                        oppiaineId: ref.id
                    });
                });
            });
        }
    });
    $scope.isMaara = function () { return $scope.oppiaine && $scope.oppiaine.oppiaineId != null; };
    $scope.openKoodisto = LukioControllerHelpers.openOppiaineKoodisto($scope.oppiaine);
    Editointikontrollit.startEditing();
})
    .controller("LukioKurssiController", function ($scope, $q, $stateParams, $state, LukioControllerHelpers, LukioOpetussuunnitelmaService, Kaanna, $log, Editointikontrollit, $timeout, Varmistusdialogi) {
    $scope.kurssi = null;
    $scope.oppiaine = null;
    $scope.editMode = false;
    $scope.rootOps = true;
    $scope.kurssiTyypit = _.map(LukioControllerHelpers.paikallisetKurssiTyypit(), function (t) { return ({
        tyyppi: t,
        nimi: "lukio-kurssi-tyyppi-otsikko-" + t.toLowerCase()
    }); });
    $scope.isPaikallinen = function () {
        return $scope.kurssi && _.any(LukioControllerHelpers.paikallisetKurssiTyypit(), function (t) { return $scope.kurssi.tyyppi == t; });
    };
    $scope.isEditable = function () { return $scope.kurssi && $scope.kurssi.oma && $scope.isPaikallinen(); };
    $scope.connected = function () { return $scope.kurssi && !$scope.kurssi.oma && !$scope.rootOps; };
    $scope.isReconnectable = function () {
        return $scope.kurssi && $scope.kurssi.oma && !$scope.rootOps && $scope.kurssi.palautettava;
    };
    $scope.isEditAllowed = function () { return $scope.kurssi && $scope.kurssi.oma; };
    $scope.isDeletable = function () {
        return ($scope.kurssi && ($scope.kurssi.oma && $scope.isPaikallinen())) ||
            $scope.kurssi.tyyppi === "VALTAKUNNALLINEN_SOVELTAVA";
    };
    LukioOpetussuunnitelmaService.getOppiaine($stateParams.oppiaineId).then(function (oa) {
        $scope.oppiaine = oa;
    });
    LukioOpetussuunnitelmaService.getRakenne().then(function (r) { return ($scope.rootOps = r.root); });
    LukioOpetussuunnitelmaService.getKurssi($stateParams.oppiaineId, $stateParams.kurssiId).then(function (kurssi) {
        $scope.inPeruste = {
            tavoitteetJaKeskeisetSisallot: _.has(kurssi, "perusteen.tavoitteetJaKeskeisetSisallot.teksti"),
            keskeisetSisallot: _.has(kurssi, "perusteen.keskeisetSisallot.teksti"),
            tavoitteet: _.has(kurssi, "perusteen.tavoitteet.teksti")
        };
        $scope.kurssi = kurssi;
        $scope.openKoodisto = LukioControllerHelpers.openKurssiKoodisto($scope.kurssi);
        $scope.muokattavatOsat = LukioControllerHelpers.muokattavatKurssiOsat($scope.kurssi);
    });
    $scope.getTyyppiSelite = function () {
        if ($scope.kurssi) {
            var tyyppi = $scope.kurssi.tyyppi;
            tyyppi = (tyyppi.indexOf("_") !== -1 ? tyyppi.split("_")[1] : tyyppi).toLowerCase();
            return "kurssi-tyyppi-selite-" + tyyppi;
        }
        return "";
    };
    Editointikontrollit.registerCallback({
        validate: function () {
            return (Kaanna.kaanna($scope.kurssi.nimi) != null &&
                Kaanna.kaanna($scope.kurssi.lokalisoituKoodi) &&
                $scope.kurssi.tyyppi != null &&
                $scope.kurssi.laajuus > 0);
        },
        edit: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.lukitseKurssi($stateParams.kurssiId).then(function () { return resolve(); });
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.vapautaKurssi($stateParams.kurssiId).then(function () {
                    $timeout(function () {
                        return $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
                            id: $stateParams.id,
                            oppiaineId: $stateParams.oppiaineId,
                            kurssiId: $stateParams.kurssiId
                        }, { reload: true, notify: true });
                    });
                    resolve();
                });
            });
        },
        save: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.updateKurssi($stateParams.kurssiId, $scope.kurssi).then(function () {
                    LukioOpetussuunnitelmaService.vapautaKurssi($stateParams.kurssiId).then(function () {
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
                                id: $stateParams.id,
                                oppiaineId: $stateParams.oppiaineId,
                                kurssiId: $stateParams.kurssiId
                            }, { reload: true, notify: true });
                        });
                        resolve();
                    });
                });
            });
        }
    });
    $scope.edit = function () {
        $scope.editMode = true;
        Editointikontrollit.startEditing();
    };
    $scope.goBack = function () {
        $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
            oppiaineId: $stateParams.oppiaineId
        });
    };
    $scope.connectKurssi = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-palauta-kurssi",
            primaryBtn: "palauta-yhteys",
            successCb: function () {
                return LukioOpetussuunnitelmaService.lukitseKurssi($stateParams.kurssiId).then(function () {
                    LukioOpetussuunnitelmaService.reconnectKurssi($stateParams.kurssiId, $stateParams.oppiaineId, $stateParams.id).then(function (r) {
                        $timeout(function () {
                            return $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
                                id: $stateParams.id,
                                oppiaineId: $stateParams.oppiaineId,
                                kurssiId: r.id
                            }, { reload: true, notify: true });
                        });
                    });
                });
            }
        })();
    };
    $scope.disconnectKurssi = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-katkaise-kurssi-yhteys",
            primaryBtn: "katkaise-yhteys",
            successCb: function () {
                return LukioOpetussuunnitelmaService.disconnectKurssi($stateParams.kurssiId, $stateParams.oppiaineId, $stateParams.id).then(function (r) {
                    $timeout(function () {
                        return $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
                            id: $stateParams.id,
                            oppiaineId: $stateParams.oppiaineId,
                            kurssiId: r.id
                        }, { reload: true, notify: true });
                    });
                });
            }
        })();
    };
    $scope["delete"] = function () {
        Varmistusdialogi.dialogi({
            otsikko: "varmista-poista-kurssi",
            primaryBtn: "poista-kurssi",
            successCb: function () {
                LukioOpetussuunnitelmaService.lukitseKurssi($stateParams.kurssiId).then(function () {
                    return LukioOpetussuunnitelmaService.removeKurssi($stateParams.kurssiId, $stateParams.id).then(function () {
                        $scope.goBack();
                    });
                });
            }
        })();
    };
})
    .controller("LuoLukioKurssiController", function ($scope, $q, $stateParams, LukioControllerHelpers, Editointikontrollit, $timeout, $state, LukioOpetussuunnitelmaService, Kaanna) {
    $scope.kurssi = {
        oppiaineId: $stateParams.oppiaineId,
        tyyppi: "PAIKALLINEN_SYVENTAVA",
        nimi: LukioControllerHelpers.kielella(""),
        laajuus: 1
    };
    $scope.editMode = true;
    $scope.oppiaine = null;
    $scope.openKoodisto = LukioControllerHelpers.openKurssiKoodisto($scope.kurssi);
    $scope.kurssiTyypit = _.map(LukioControllerHelpers.paikallisetKurssiTyypit(), function (t) { return ({
        tyyppi: t,
        nimi: "lukio-kurssi-tyyppi-otsikko-" + t.toLowerCase()
    }); });
    LukioOpetussuunnitelmaService.getOppiaine($stateParams.oppiaineId).then(function (oa) {
        $scope.oppiaine = oa;
    });
    $scope.muokattavatOsat = LukioControllerHelpers.muokattavatKurssiOsat($scope.kurssi);
    Editointikontrollit.registerCallback({
        validate: function () {
            return (Kaanna.kaanna($scope.kurssi.nimi) != null &&
                Kaanna.kaanna($scope.kurssi.lokalisoituKoodi) &&
                $scope.kurssi.tyyppi != null &&
                $scope.kurssi.laajuus > 0);
        },
        edit: function () {
            return $q(function (resolve) {
                resolve();
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                $timeout(function () {
                    return $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                        id: $stateParams.id,
                        oppiaineId: $stateParams.oppiaineId
                    });
                });
                resolve();
            });
        },
        save: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.saveKurssi($scope.kurssi).then(function (res) {
                    $timeout(function () {
                        return $state.go("root.opetussuunnitelmat.lukio.opetus.kurssi", {
                            id: $stateParams.id,
                            oppiaineId: $stateParams.oppiaineId,
                            kurssiId: res.id
                        });
                    });
                    resolve();
                });
            });
        }
    });
    Editointikontrollit.startEditing();
})
    .controller("LukioOppiaineSisaltoController", function ($scope) {
    $scope.textHidden = false;
    $scope.editing = false;
    $scope.toggleTextVisible = function () {
        $scope.textHidden = !$scope.textHidden;
    };
    $scope.edit = function () {
        $scope.editing = true;
    };
})
    .directive("lukioOppiaineOsa", function () {
    return {
        scope: {
            model: "=lukioOppiaineOsa",
            oppiaine: "=?oppiaine",
            perusteenTeksti: "=?perusteenTeksti",
            oppiaineenTeksti: "=?oppiaineenTeksti",
            sisaltoTitle: "=?sisaltoTitle",
            colorbox: "=?colorbox",
            ikoni: "=?ikoni",
            editable: "=?editable",
            editing: "=?editing",
            pohjanTeksti: "=?pohjanTeksti"
        },
        templateUrl: "views/opetussuunnitelmat/directives/oppiaineSisalto.html",
        controller: "LukioOppiaineSisaltoController"
    };
})
    .controller("LukioPerusteenSisaltoController", function ($scope) {
    $scope.textHidden = true;
    $scope.toggleTextVisible = function () {
        $scope.textHidden = !$scope.textHidden;
    };
})
    .directive("lukoiPerusteenSisalto", function () {
    return {
        scope: {
            model: "=lukiPerusteen",
            perusteenTeksti: "=?perusteenTeksti"
        },
        templateUrl: "views/opetussuunnitelmat/directives/lukiPerusteenSisalto.html",
        controller: "LukioPerusteenSisaltoController"
    };
})
    .controller("LukioKielitarjontaModalController", function ($scope, $stateParams, $modalInstance, $q, OpsService, $log, $state, opsId, oppiaine, valittu, LukioOpetussuunnitelmaService, Notifikaatiot, LukioControllerHelpers, Kaanna) {
    var getType = function () {
        if (!_.isString(oppiaine.koodiArvo)) {
            $log.warn("Oppiaineen koodia ei ole määritelty");
            return "";
        }
        if (OpsService.oppiaineIsKieli(oppiaine)) {
            return "kieli";
        }
        else if (oppiaine.koodiArvo === "KT") {
            return "uskonto";
        }
        else if (oppiaine.koodiArvo === "AI") {
            return "aidinkieli";
        }
        else {
            $log.warn("Oppiaineen täytyy olla kieli tai uskonto");
            return "";
        }
    };
    $scope.$type = getType();
    $scope.oppiaine = oppiaine;
    $scope.$valittu = _.cloneDeep(valittu);
    $scope.$valittu.kieli = LukioControllerHelpers.kielella("");
    $scope.$omaNimi =
        !$scope.$type || $scope.$type == "uskonto"
            ? _.cloneDeep($scope.$valittu.nimi)
            : LukioControllerHelpers.kielella("");
    $scope.$concretet = _.reject(oppiaine.perusteen != null ? oppiaine.perusteen.oppimaarat : [], function (om) { return om.abstrakti; });
    $scope.openKieliKoodisto = LukioControllerHelpers.openOppiaineKieliKoodisto($scope.$valittu, function (koodi) {
        var osat = Kaanna.kaanna($scope.$valittu.nimi).split(/\s*,\s*/), kaannettyKieli = Kaanna.kaanna(koodi.nimi);
        if (!Kaanna.kaanna($scope.$omaNimi)) {
            if ($scope.$type == "kieli" && kaannettyKieli && osat.length == 2) {
                $log.info($scope.$valittu.koodiArvo);
                $scope.$omaNimi = LukioControllerHelpers.kielella(($scope.$valittu.koodiArvo == "KX" ? "" : kaannettyKieli) + ", " + osat[1].trim());
            }
            else {
                $scope.$omaNimi = _.cloneDeep($scope.$valittu.nimi);
            }
        }
    });
    $scope.kieliJoToteutettu = function () {
        if ($scope.$type != "kieli") {
            return false;
        }
        return _.any(oppiaine.oppimaarat, function (om) {
            return (om.tunniste == $scope.$valittu.tunniste &&
                om.kieliKoodiArvo == $scope.$valittu.kieliKoodiArvo &&
                ($scope.$valittu.kieliKoodiArvo != "KX" ||
                    _.isEqual(_.omit(_.pick(om.kieli, _.identity), "_id"), _.omit(_.pick($scope.$valittu.kieli, _.identity), "_id"))));
        });
    };
    $scope.ok = function () {
        if (!$scope.kieliJoToteutettu()) {
            LukioOpetussuunnitelmaService.addKielitarjonta(oppiaine.id, {
                tunniste: $scope.$valittu.tunniste,
                nimi: $scope.$omaNimi,
                kieliKoodiArvo: $scope.$valittu.kieliKoodiArvo,
                kieliKoodiUri: $scope.$valittu.kieliKoodiUri,
                kieli: $scope.$valittu.kieli
            }, opsId).then(function (res) {
                $modalInstance.close(res);
                Notifikaatiot.onnistui("tallennettu-ok");
            }, Notifikaatiot.serverCb);
        }
    };
    $scope.peruuta = $modalInstance.dismiss;
})
    .controller("LukioTuoAbstraktiOppiaineController", function ($scope, $stateParams, $modalInstance, $q, OpsService, $log, $state, opsId, valittu, LukioOpetussuunnitelmaService, Notifikaatiot, LukioControllerHelpers) {
    $scope.$valittu = _.cloneDeep(valittu);
    $scope.$valittu.kieli = LukioControllerHelpers.kielella("");
    $scope.$omaNimi = _.cloneDeep($scope.$valittu.nimi);
    $scope.ok = function () {
        LukioOpetussuunnitelmaService.addAbstraktiOppiaine({
            tunniste: $scope.$valittu.tunniste,
            nimi: $scope.$omaNimi
        }, opsId).then(function (res) {
            $modalInstance.close(res);
            Notifikaatiot.onnistui("tallennettu-ok");
        }, Notifikaatiot.serverCb);
    };
    $scope.peruuta = $modalInstance.dismiss;
});
//# sourceMappingURL=lukioOppiaineetControllers.js.map