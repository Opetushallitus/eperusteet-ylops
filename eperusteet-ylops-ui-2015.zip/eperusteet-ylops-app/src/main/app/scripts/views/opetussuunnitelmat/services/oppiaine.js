"use strict";
ylopsApp.service("OppiaineService", function (VuosiluokatService, $rootScope, MurupolkuData, $q, OppiaineCRUD, OppiaineenVlk, Notifikaatiot, VuosiluokkaCRUD) {
    var vlkTunniste = null;
    var oppiaineenVlk = null;
    var oppiaine = null;
    var opetussuunnitelma = null;
    function setup(ops, vlkId, oppiaineModel) {
        return $q(function (resolve, reject) {
            opetussuunnitelma = ops;
            oppiaine = oppiaineModel;
            MurupolkuData.set("oppiaineNimi", oppiaine.nimi);
            var opsVlk = _.find(ops.vuosiluokkakokonaisuudet, function (vlk) {
                return "" + vlk.vuosiluokkakokonaisuus.id === vlkId;
            });
            vlkTunniste = opsVlk ? opsVlk.vuosiluokkakokonaisuus._tunniste : null;
            oppiaineenVlk = _.find(oppiaine.vuosiluokkakokonaisuudet, function (opVlk) {
                return opVlk._vuosiluokkakokonaisuus === vlkTunniste;
            });
            resolve();
        });
    }
    this.getParent = function () {
        return OppiaineCRUD.getParent({
            opsId: opetussuunnitelma.id,
            oppiaineId: oppiaine.id
        }).$promise;
    };
    this.revertToVersion = function (version) {
        return OppiaineCRUD.revertToVersion({
            opsId: opetussuunnitelma.id,
            oppiaineId: oppiaine.id,
            versio: version
        }, {}).$promise;
    };
    this.getVersions = function (params) {
        return OppiaineCRUD.getVersions({ opsId: params.id, oppiaineId: params.oppiaineId }).$promise;
    };
    this.palauta = function (params) {
        return OppiaineCRUD.palautaOppiaine({ opsId: params.opsId, oppiaineId: params.id, oppimaara: params.oppimaara }, {}).$promise;
    };
    this.refresh = function (ops, oppiaineId, vlkId, versio) {
        return $q(function (resolve, reject) {
            VuosiluokatService.getOppiaine(oppiaineId, versio)
                .$promise.then(function (res) {
                setup(ops, vlkId, res).then(resolve);
                $rootScope.$broadcast("oppiainevlk:updated", oppiaineenVlk);
            })["catch"](reject);
        });
    };
    this.getOpVlk = function () {
        return oppiaineenVlk;
    };
    this.getOppiaine = function () {
        return oppiaine;
    };
    this.saveVlk = function (model) {
        return $q(function (resolve) {
            OppiaineenVlk.save({
                opsId: opetussuunnitelma.id,
                oppiaineId: oppiaine.id
            }, model, function () {
                Notifikaatiot.onnistui("tallennettu-ok");
                $rootScope.$broadcast("oppiaine:reload");
                resolve();
            }, Notifikaatiot.serverCb);
        });
    };
    this.fetchVlk = function (vlkId, cb) {
        return OppiaineenVlk.get({
            opsId: opetussuunnitelma.id,
            oppiaineId: oppiaine.id,
            vlkId: vlkId
        }, cb, Notifikaatiot.serverCb).$promise;
    };
    this.saveVuosiluokka = function (model, cb) {
        VuosiluokkaCRUD.save({
            opsId: opetussuunnitelma.id,
            vlkId: oppiaineenVlk.id,
            oppiaineId: oppiaine.id
        }, model, function (res) {
            Notifikaatiot.onnistui("tallennettu-ok");
            cb(res);
        }, Notifikaatiot.serverCb);
    };
    this.saveValinnainenVuosiluokka = function (vlId, model, cb) {
        VuosiluokkaCRUD.saveValinnainen({
            opsId: opetussuunnitelma.id,
            vlkId: oppiaineenVlk.id,
            oppiaineId: oppiaine.id,
            vvlId: vlId
        }, model, function (res) {
            cb(res);
        }, Notifikaatiot.serverCb);
    };
    this.fetchVuosiluokka = function (vlId, cb) {
        VuosiluokkaCRUD.get({
            opsId: opetussuunnitelma.id,
            oppiaineId: oppiaine.id,
            vlkId: oppiaineenVlk.id,
            vlId: vlId
        }, cb, Notifikaatiot.serverCb);
    };
});
//# sourceMappingURL=oppiaine.js.map