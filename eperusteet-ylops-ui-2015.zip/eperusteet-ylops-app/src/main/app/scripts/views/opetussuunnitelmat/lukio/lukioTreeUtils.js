"use strict";
var LukioKurssiTreeNodeType;
(function (LukioKurssiTreeNodeType) {
    LukioKurssiTreeNodeType[LukioKurssiTreeNodeType["root"] = 0] = "root";
    LukioKurssiTreeNodeType[LukioKurssiTreeNodeType["kurssi"] = 1] = "kurssi";
    LukioKurssiTreeNodeType[LukioKurssiTreeNodeType["oppiaine"] = 2] = "oppiaine";
})(LukioKurssiTreeNodeType || (LukioKurssiTreeNodeType = {}));
ylopsApp.service("LukioTreeUtils", function ($log, $state, $stateParams, Kaanna, Kieli, $timeout, $rootScope, $filter) {
    var transformKurssitToTreeNodes = function (ks) {
        var nodes = [];
        _.each(ks, function (k) {
            var node = _.clone(k);
            node.dtype = LukioKurssiTreeNodeType.kurssi;
            node.lapset = [];
            node.$$tyyppi = node.tyyppi.toLowerCase();
            nodes.push(node);
        });
        return nodes;
    };
    var transformOppiaineToTreeNodes = function (oas) {
        var nodes = [];
        _.each(oas, function (oa) {
            var node = _.clone(oa);
            node.dtype = LukioKurssiTreeNodeType.oppiaine;
            node.lapset = _.union(transformOppiaineToTreeNodes(oa.oppimaarat || []), transformKurssitToTreeNodes(oa.kurssit || []));
            _.each(node.lapset, function (lapsi) {
                lapsi.$$nodeParent = node;
            });
            nodes.push(node);
        });
        return nodes;
    };
    var treeRootLapsetFromRakenne = function (rakenne) {
        return transformOppiaineToTreeNodes(rakenne.oppiaineet);
    };
    var textMatch = function (txt, to) {
        if (!to) {
            return true;
        }
        if (!txt.length) {
            return false;
        }
        var words = to.toLowerCase().split(/\s+/);
        var found = {};
        for (var part in txt) {
            if (!txt[part]) {
                continue;
            }
            var lower = txt[part].toLowerCase();
            for (var i in words) {
                if (words[i] && lower.indexOf(words[i]) !== -1) {
                    found[i] = true;
                }
            }
        }
        for (var j = 0; j < words.length; ++j) {
            if (!found[j]) {
                return false;
            }
        }
        return true;
    };
    var matchesSearch = function (node, search) {
        if (!search) {
            return true;
        }
        var nimi = node.nimi;
        var koodiArvo = node.koodiArvo;
        var lokalisoituKoodi = node.lokalisoituKoodi ? Kaanna.kaanna(node.lokalisoituKoodi) : null;
        if (_.isObject(node.nimi)) {
            nimi = nimi[Kieli.getSisaltokieli().toLowerCase()];
        }
        return textMatch([nimi, koodiArvo, lokalisoituKoodi], search);
    };
    var search = function (root, search) {
        var ftree = _(root)
            .flattenTree(function (n) { return n.lapset; })
            .filter(function (n) { return n.dtype != LukioKurssiTreeNodeType.root; })
            .value();
        _.each(ftree, function (n) {
            n.$$hide = !matchesSearch(n, search);
            if (!n.$$hide) {
                _.each(_.flattenTree(n, function (node) { return node.$$nodeParent; }), function (node) {
                    node.$$hide = false;
                });
            }
        });
    };
    var buildTree = function (rakenne) {
        var root = {
            dtype: LukioKurssiTreeNodeType.root,
            lapset: []
        };
        _.each(treeRootLapsetFromRakenne(rakenne), function (lapsi) {
            root.lapset.push(lapsi);
        });
        return root;
    };
    return {
        search: search,
        buildTree: buildTree
    };
});
//# sourceMappingURL=lukioTreeUtils.js.map