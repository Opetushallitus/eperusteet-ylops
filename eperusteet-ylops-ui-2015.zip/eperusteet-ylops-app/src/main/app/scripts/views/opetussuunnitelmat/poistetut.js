"use strict";
ylopsApp
    .controller("OpetussuunnitelmaPoistetutController", function (tekstiKappaleet, oppiaineet, $scope, OpetussuunnitelmanTekstit, $stateParams, $state, Algoritmit, $filter, OppiaineService, $modal, OpetussuunnitelmaCRUD, Notifikaatiot, EperusteetKayttajatiedot, $q) {
    $scope.kaikki = [];
    $scope.currentPage = 1;
    $scope.itemsPerPage = 10;
    $scope.haku = "";
    var isLukio = function () {
        return _.any(["koulutustyyppi_2", "koulutustyyppi_23", "koulutustyyppi_14"], function (i) { return i === $scope.model.koulutustyyppi; });
    };
    var addItems = function (items, type) {
        var reqs = [];
        _.forEach(_.uniq(items, "luoja"), function (i) {
            return reqs.push(EperusteetKayttajatiedot.get({ oid: i.luoja }).$promise);
        });
        reqs.push();
        $q.all(reqs).then(function (values) {
            _.forEach(items, function (item) {
                var henkilo = _.find(values, function (i) { return i.oidHenkilo === item.luoja; });
                var nimi = _.isEmpty(henkilo)
                    ? " "
                    : (henkilo.kutsumanimi || "") + " " + (henkilo.sukunimi || "");
                item.luoja = nimi === " " ? item.luoja : nimi;
            });
        });
        _.forEach(items, function (item) {
            item.type = type;
            $scope.kaikki.push(item);
        });
    };
    addItems(tekstiKappaleet, "teksti");
    addItems(oppiaineet, "oppiaine");
    $scope.kaikki = _.sortBy($scope.kaikki, "luotu");
    $scope.poistetut = $scope.kaikki;
    $scope.$watch("haku", function (searchString) {
        if (_.isEmpty(searchString)) {
            $scope.poistetut = $scope.kaikki;
            return;
        }
        $scope.poistetut = _.filter($scope.kaikki, function (item) {
            var matchRemover = Algoritmit.match(searchString, item.luoja);
            var matchRemovedDate = Algoritmit.match(searchString, $filter("aikaleima")(item.luotu, "date"));
            var matchTextTitle = Algoritmit.match(searchString, item.nimi);
            return matchRemover || matchRemovedDate || matchTextTitle;
        });
    });
    $scope.clearSearch = function () {
        $scope.haku = "";
    };
    var palautaOppiaine = function (params) {
        $modal
            .open({
            templateUrl: "views/common/modals/oppiainePalautus.html",
            controller: "OppiaineModalController",
            size: "lg",
            resolve: {
                ops: function () {
                    return OpetussuunnitelmaCRUD.get({ opsId: params.opsId }, {}).$promise;
                }
            }
        })
            .result.then(function (palautettava) {
            params.oppimaara =
                palautettava.type === "oppimaara" ? palautettava.oppimaara.oppiaine.id : null;
            OppiaineService.palauta(params, {}).then(function (palautettu) {
                if (isLukio()) {
                    $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                        id: $stateParams.id,
                        oppiaineId: palautettu.id
                    }, { reload: true, notify: true });
                }
                else {
                    $state.go("root.opetussuunnitelmat.yksi.opetus.oppiaine.oppiaine", {
                        oppiaineId: palautettu.id,
                        vlkId: palautettu.vlkId,
                        oppiaineTyyppi: palautettu.tyyppi
                    }, { reload: true, notify: true });
                }
            }, function () {
                Notifikaatiot.fataali("palautus-epaonnistui");
            });
        });
    };
    $scope.returnVersion = function (id, type) {
        var params = {
            opsId: parseInt($stateParams.id),
            id: id
        };
        if (type === "oppiaine") {
            palautaOppiaine(params);
        }
        else if (type === "teksti") {
            OpetussuunnitelmanTekstit.palauta(params, {}).$promise.then(function () {
                $state.go("root.opetussuunnitelmat.yksi.sisalto", { reload: true });
            });
        }
    };
})
    .controller("OppiaineModalController", function (ops, $scope, OppiaineService, $modalInstance) {
    $scope.koosteiset = _.filter(ops.oppiaineet, "oppiaine.koosteinen");
    $scope.palauta = {
        type: "oppiaine"
    };
    $scope.isValid = function () {
        return $scope.palauta.type === "oppimaara" ? !_.isEmpty($scope.palauta.oppimaara) : true;
    };
    $scope.ok = function () { return $modalInstance.close($scope.palauta); };
    $scope.peruuta = function () { return $modalInstance.dismiss(); };
});
//# sourceMappingURL=poistetut.js.map