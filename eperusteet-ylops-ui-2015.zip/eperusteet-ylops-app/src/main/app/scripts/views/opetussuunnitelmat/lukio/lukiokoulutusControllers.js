"use strict";
ylopsApp
    .service("LukioNavigaatioProvider", function ($state, $q, LukioOpetussuunnitelmaService, Kaanna) {
    var buildNavigation = function () {
        var d = $q.defer(), aihekok = null, rakenne = null;
        $q
            .all([
            LukioOpetussuunnitelmaService.getAihekokonaisuudet().then(function (ak) { return (aihekok = ak); }),
            LukioOpetussuunnitelmaService.getRakenne().then(function (r) { return (rakenne = r); })
        ])
            .then(function () {
            var items = [
                {
                    url: $state.href("root.opetussuunnitelmat.lukio.opetus.yleisettavoitteet"),
                    label: "lukio-opetuksen-yleiset-tavoitteet",
                    depth: 0
                },
                {
                    url: $state.href("root.opetussuunnitelmat.lukio.opetus.aihekokonaisuudet"),
                    label: "lukio-aihekokonaisuudet",
                    depth: 0
                }
            ];
            if (aihekok.paikallinen) {
                _.each(aihekok.paikallinen.aihekokonaisuudet, function (ak) {
                    return items.push({
                        url: $state.href("root.opetussuunnitelmat.lukio.opetus.aihekokonaisuus", {
                            aihekokonaisuusId: ak.id
                        }),
                        label: Kaanna.kaanna(ak.otsikko || (ak.perusteen ? ak.perusteen.otsikko : {})),
                        depth: 1
                    });
                });
            }
            items.push({
                url: $state.href("root.opetussuunnitelmat.lukio.opetus.oppiaineet"),
                label: "lukio-oppiaineet-oppimaarat",
                depth: 0
            });
            var mapOppiaine = function (oa, dept) {
                items.push({
                    url: $state.href("root.opetussuunnitelmat.lukio.opetus.oppiaine", {
                        oppiaineId: oa.id
                    }),
                    label: oa.nimi,
                    depth: dept
                });
                _.each(oa.oppimaarat, function (om) { return mapOppiaine(om, dept + 1); });
            };
            _.each(rakenne.oppiaineet, function (oa) { return mapOppiaine(oa, 1); });
            d.resolve(items);
        });
        return d.promise;
    };
    var produceNavigation = function (doUpateItems) {
        var doBuild = function () { return buildNavigation().then(doUpateItems); };
        LukioOpetussuunnitelmaService.onAihekokonaisuudetUpdate(doBuild);
        LukioOpetussuunnitelmaService.onRakenneUpdate(doBuild);
        return doBuild();
    };
    return {
        produceNavigation: produceNavigation
    };
})
    .controller("LukioOpetusController", function ($scope, LukioNavigaatioProvider, MurupolkuData, $state, $log) {
    $scope.navi = [];
    LukioNavigaatioProvider.produceNavigation(function (newItems) {
        $scope.navi.length = 0;
        _.each(newItems, function (i) { return $scope.navi.push(i); });
        $scope.$broadcast("navigaatio:setNavi", $scope.navi);
        return newItems;
    });
    if ($state.is("root.opetussuunnitelmat.lukio.opetus")) {
        $state.go("root.opetussuunnitelmat.lukio.opetus.oppiaineet");
    }
})
    .controller("OpetuksenYleisetTavoitteetController", function ($scope, $state, $log, $q, Notifikaatiot, $timeout, LukioOpetussuunnitelmaService, Editointikontrollit) {
    $scope.yleisetTavoitteet = {};
    LukioOpetussuunnitelmaService.getOpetuksenYleisetTavoitteet().then(function (yt) { return ($scope.yleisetTavoitteet = yt); });
    $scope.editMode = false;
    Editointikontrollit.registerCallback({
        validate: function () {
            return true;
        },
        edit: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.lukitseYleisetTavoitteet().then(function () {
                    $scope.editMode = true;
                    resolve();
                });
            });
        },
        cancel: function () {
            return $q(function (resolve) {
                LukioOpetussuunnitelmaService.vapautaYleisetTavoitteet().then(function () {
                    resolve();
                    $scope.editMode = false;
                    $timeout(function () { return $state.reload(); });
                });
            });
        },
        save: function () {
            return $q(function (resolve) {
                $scope.yleiskuvaEditMode = false;
                LukioOpetussuunnitelmaService.updateYleisetTavoitteet($scope.yleisetTavoitteet.paikallinen).then(function () {
                    Notifikaatiot.onnistui("opetuksen-yleisten-tavoitteiden-yleiskuvauksen-paivitys-onnistui");
                    LukioOpetussuunnitelmaService.vapautaYleisetTavoitteet().then(function () {
                        resolve();
                        $scope.editMode = false;
                        $timeout(function () { return $state.reload(); });
                    });
                });
            });
        }
    });
    $scope.toEditMode = function () {
        Editointikontrollit.startEditing();
    };
});
//# sourceMappingURL=lukiokoulutusControllers.js.map