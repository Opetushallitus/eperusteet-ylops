"use strict";
ylopsApp.service("LukioOpetussuunnitelmaService", function (OpetusuunnitelmaLukio, $q, $log, Lukko, Notifikaatiot, $stateParams, OppiaineCRUD) {
    var doGetAihekokonaisuudet = function (opsId, d) {
        return OpetusuunnitelmaLukio.aihekokonaisuudet({ opsId: opsId || $stateParams.id }).$promise.then(function (aihekok) { return d.resolve(aihekok); }, Notifikaatiot.serverCb);
    };
    var aiheKokCache = cached($q, doGetAihekokonaisuudet);
    var getAihekokonaisuudet = function (opsId) { return aiheKokCache.get(opsId || $stateParams.id); };
    var lukitseAihekokonaisuudet = function (id, opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "AIHEKOKONAISUUDET"
        });
    };
    var vapautaAihekokonaisuudet = function (id, opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "AIHEKOKONAISUUDET"
        });
    };
    var rearrangeAihekokonaisuudet = function (jarjestys, opsId) {
        return OpetusuunnitelmaLukio.rearrangeAihekokonaisuudet({ opsId: opsId || $stateParams.id }, jarjestys).$promise.then(function (r) {
            aiheKokCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var updateAihekokonaisuudetYleiskuvaus = function (yleiskuvaus, opsId) {
        return OpetusuunnitelmaLukio.updateAihekokonaisuudetYleiskuvaus({ opsId: opsId || $stateParams.id }, yleiskuvaus).$promise.then(function (r) {
            aiheKokCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var kokonaisuusCache = aiheKokCache.related(function (from) {
        return _(from.paikallinen.aihekokonaisuudet)
            .indexBy(_.property("id"))
            .value();
    });
    var getAihekokonaisuus = function (id, opsId) { return kokonaisuusCache.get(opsId || $stateParams.id, id); };
    var lukitseAihekokonaisuus = function (id, opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "AIHEKOKONAISUUS"
        });
    };
    var vapautaAihekokonaisuus = function (id, opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "AIHEKOKONAISUUS"
        });
    };
    var saveAihekokonaisuus = function (aihekok, opsId) {
        return OpetusuunnitelmaLukio.saveAihekokonaisuus({ opsId: opsId || $stateParams.id }, aihekok).$promise.then(function (r) {
            kokonaisuusCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var updateAihekokonaisuus = function (id, aihekok, opsId) {
        return OpetusuunnitelmaLukio.updateAihekokonaisuus({ opsId: opsId || $stateParams.id, aihekokonaisuusId: id }, aihekok).$promise.then(function (r) {
            aiheKokCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var deleteAihekokonaisuus = function (aihekokId, opsId) {
        return OpetusuunnitelmaLukio.deleteAihekokonaisuus({
            opsId: opsId || $stateParams.id,
            aihekokonaisuusId: aihekokId
        }).$promise.then(function (r) {
            aiheKokCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var doGetOpetuksenYleisetTavoitteet = function (opsId, d) {
        return OpetusuunnitelmaLukio.opetuksenYleisetTavoitteet({ opsId: opsId || $stateParams.id }).$promise.then(function (yleisetTavoitteet) { return d.resolve(yleisetTavoitteet); }, Notifikaatiot.serverCb);
    };
    var yleisetTavoitteetCache = cached($q, doGetOpetuksenYleisetTavoitteet);
    var getOpetuksenYleisetTavoitteet = function (opsId) { return yleisetTavoitteetCache.get(opsId || $stateParams.id); };
    var lukitseYleisetTavoitteet = function (opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: opsId || $stateParams.id,
            lukittavaOsa: "YLEISET_TAVOITTEET"
        });
    };
    var vapautaYleisetTavoitteet = function (opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: opsId || $stateParams.id,
            lukittavaOsa: "YLEISET_TAVOITTEET"
        });
    };
    var updateYleisetTavoitteet = function (tavoitteet, opsId) {
        return OpetusuunnitelmaLukio.updateOpetuksenYleisetTavoitteet({ opsId: opsId || $stateParams.id }, tavoitteet).$promise.then(function (r) {
            yleisetTavoitteetCache.clear();
            return r;
        });
    };
    var doGetRakenne = function (id, d) {
        return OpetusuunnitelmaLukio.rakenne({ opsId: id }).$promise.then(function (rakenne) { return d.resolve(rakenne); }, Notifikaatiot.serverCb);
    };
    var rakenneCache = cached($q, doGetRakenne);
    var lukitseRakenne = function (opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: opsId || $stateParams.id,
            lukittavaOsa: "OPS"
        });
    };
    var vapautaRakenne = function (opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: opsId || $stateParams.id,
            lukittavaOsa: "OPS"
        });
    };
    var getRakenne = function (id) { return rakenneCache.get(id || $stateParams.id); };
    var updateOppiaineKurssiStructure = function (treeRoot, kommentti, opsId) {
        var chain = _(treeRoot).flattenTree(function (node) {
            var kurssiJarjestys = 1, oppiaineJarjestys = 1;
            return _(node.lapset)
                .map(function (n) {
                if (n.dtype == LukioKurssiTreeNodeType.kurssi) {
                    return {
                        id: n.id,
                        dtype: LukioKurssiTreeNodeType.kurssi,
                        oppiaineet: [
                            {
                                oppiaineId: node.id,
                                jarjestys: kurssiJarjestys++
                            }
                        ]
                    };
                }
                else {
                    return {
                        id: n.id,
                        dtype: LukioKurssiTreeNodeType.oppiaine,
                        jarjestys: oppiaineJarjestys++,
                        lapset: n.lapset
                    };
                }
            })
                .value();
        }), update = {
            oppiaineet: chain.filter(function (n) { return n && n.dtype == LukioKurssiTreeNodeType.oppiaine; }).value(),
            kurssit: chain
                .filter(function (n) { return n.dtype == LukioKurssiTreeNodeType.kurssi; })
                .reducedIndexOf(function (n) { return n.id; }, function (a, b) {
                var c = _.clone(a);
                c.oppiaineet = _.union(a.oppiaineet, b.oppiaineet);
                return c;
            })
                .values()
                .value(),
            kommentti: kommentti
        };
        return OpetusuunnitelmaLukio.updateStructure({
            opsId: opsId || $stateParams.id
        }, update).$promise.then(function (res) {
            rakenneCache.clear();
            return res;
        }, Notifikaatiot.serverCb);
    };
    var combineWithOpsId = function (opsId, id) { return (opsId ? opsId + "/" + id : id); };
    var doGetOppiaine = function (oppiaineWithOpsId, d) {
        var prts = ("" + oppiaineWithOpsId).split("/");
        var opsId = $stateParams.id, oppiaineId = null;
        if (prts.length > 1) {
            opsId = prts[0];
            oppiaineId = prts[1];
        }
        else {
            oppiaineId = prts[0];
        }
        return OpetusuunnitelmaLukio.oppiaine({ opsId: opsId, oppiaineId: oppiaineId }).$promise.then(function (oa) { return d.resolve(oa); }, Notifikaatiot.serverCb);
    };
    var oppiaineCache = cached($q, doGetOppiaine).alsoClear(rakenneCache);
    var getOppiaine = function (id, opsId) { return oppiaineCache.get(combineWithOpsId(opsId, id)); };
    var lukitseOppiaine = function (id, opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "OPPIAINE"
        });
    };
    var vapautaOppiaine = function (id, opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "OPPIAINE"
        });
    };
    var saveOppiaine = function (oppiaine, opsId) {
        return OpetusuunnitelmaLukio.saveOppiaine({ opsId: opsId || $stateParams.id }, oppiaine).$promise.then(function (r) {
            oppiaineCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var kloonaaOppiaineMuokattavaksi = function (oppiaineId, opsId) {
        return OppiaineCRUD.kloonaaMuokattavaksi({
            opsId: opsId || $stateParams.id,
            oppiaineId: oppiaineId
        }, {}).$promise.then(function (res) {
            oppiaineCache.clear();
            return res;
        }, Notifikaatiot.serverCb);
    };
    var palautaYlempaan = function (oppiaineId, opsId) {
        return OppiaineCRUD.palautaYlempaan({
            opsId: opsId || $stateParams.id,
            oppiaineId: oppiaineId
        }, {}).$promise.then(function (res) {
            oppiaineCache.clear();
            return res;
        }, Notifikaatiot.serverCb);
    };
    var updateOppiaine = function (oppiaine, opsId) {
        return OpetusuunnitelmaLukio.updateOppiaine({ opsId: opsId || $stateParams.id }, oppiaine).$promise.then(function (r) {
            oppiaineCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var addKielitarjonta = function (oppiaineId, tarjonta, opsId) {
        return OpetusuunnitelmaLukio.addKielitarjonta({ oppiaineId: oppiaineId, opsId: opsId || $stateParams.id }, tarjonta).$promise.then(function (r) {
            oppiaineCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var addAbstraktiOppiaine = function (tarjonta, opsId) {
        return OpetusuunnitelmaLukio.addAbstraktiOppiaine({ opsId: opsId || $stateParams.id }, tarjonta).$promise.then(function (r) {
            oppiaineCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var deleteOppiaine = function (oppiaineId, opsId) {
        return OppiaineCRUD["delete"]({ oppiaineId: oppiaineId, opsId: opsId || $stateParams.id }).$promise.then(function () {
            oppiaineCache.clear();
        }, Notifikaatiot.serverCb);
    };
    var kurssiCache = oppiaineCache.related(function (from) {
        return _(from.kurssit)
            .indexBy(_.property("id"))
            .value();
    });
    var getKurssi = function (oppiaineId, kurssiId, opsId) {
        return kurssiCache.get(combineWithOpsId(opsId, oppiaineId), kurssiId);
    };
    var lukitseKurssi = function (id, opsId) {
        return Lukko.lockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "LUKIOKURSSI"
        });
    };
    var vapautaKurssi = function (id, opsId) {
        return Lukko.unlockLukio({
            opsId: opsId || $stateParams.id,
            id: id,
            lukittavaOsa: "LUKIOKURSSI"
        });
    };
    var saveKurssi = function (kurssi, opsId) {
        return OpetusuunnitelmaLukio.saveKurssi({ opsId: opsId || $stateParams.id }, kurssi).$promise.then(function (r) {
            kurssiCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var updateKurssi = function (kurssiId, kurssi, opsId) {
        return OpetusuunnitelmaLukio.updateKurssi({ kurssiId: kurssiId, opsId: opsId || $stateParams.id }, kurssi).$promise.then(function (r) {
            kurssiCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var disconnectKurssi = function (kurssiId, oppiaineId, opsId) {
        return OpetusuunnitelmaLukio.disconnectKurssi({ kurssiId: kurssiId, opsId: opsId || $stateParams.id, oppiaineId: $stateParams.oppiaineId }, {}).$promise.then(function (r) {
            kurssiCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var reconnectKurssi = function (kurssiId, oppiaineId, opsId) {
        return OpetusuunnitelmaLukio.reconnectKurssi({ kurssiId: kurssiId, opsId: opsId || $stateParams.id, oppiaineId: $stateParams.oppiaineId }, {}).$promise.then(function (r) {
            kurssiCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    var removeKurssi = function (kurssiId, opsId) {
        return OpetusuunnitelmaLukio.removeKurssi({ kurssiId: kurssiId, opsId: opsId || $stateParams.id }, {}).$promise.then(function (r) {
            kurssiCache.clear();
            return r;
        }, Notifikaatiot.serverCb);
    };
    return {
        getAihekokonaisuudet: getAihekokonaisuudet,
        lukitseAihekokonaisuudet: lukitseAihekokonaisuudet,
        vapautaAihekokonaisuudet: vapautaAihekokonaisuudet,
        rearrangeAihekokonaisuudet: rearrangeAihekokonaisuudet,
        updateAihekokonaisuudetYleiskuvaus: updateAihekokonaisuudetYleiskuvaus,
        getAihekokonaisuus: getAihekokonaisuus,
        lukitseAihekokonaisuus: lukitseAihekokonaisuus,
        vapautaAihekokonaisuus: vapautaAihekokonaisuus,
        saveAihekokonaisuus: saveAihekokonaisuus,
        updateAihekokonaisuus: updateAihekokonaisuus,
        deleteAihekokonaisuus: deleteAihekokonaisuus,
        getOpetuksenYleisetTavoitteet: getOpetuksenYleisetTavoitteet,
        lukitseYleisetTavoitteet: lukitseYleisetTavoitteet,
        vapautaYleisetTavoitteet: vapautaYleisetTavoitteet,
        updateYleisetTavoitteet: updateYleisetTavoitteet,
        onAihekokonaisuudetUpdate: function (then) { return aiheKokCache.onUpdate(then); },
        onRakenneUpdate: function (then) { return rakenneCache.onUpdate(then); },
        getRakenne: getRakenne,
        lukitseRakenne: lukitseRakenne,
        vapautaRakenne: vapautaRakenne,
        updateOppiaineKurssiStructure: updateOppiaineKurssiStructure,
        getOppiaine: getOppiaine,
        lukitseOppiaine: lukitseOppiaine,
        vapautaOppiaine: vapautaOppiaine,
        saveOppiaine: saveOppiaine,
        updateOppiaine: updateOppiaine,
        kloonaaOppiaineMuokattavaksi: kloonaaOppiaineMuokattavaksi,
        palautaYlempaan: palautaYlempaan,
        addKielitarjonta: addKielitarjonta,
        addAbstraktiOppiaine: addAbstraktiOppiaine,
        deleteOppiaine: deleteOppiaine,
        getKurssi: getKurssi,
        lukitseKurssi: lukitseKurssi,
        vapautaKurssi: vapautaKurssi,
        saveKurssi: saveKurssi,
        updateKurssi: updateKurssi,
        reconnectKurssi: reconnectKurssi,
        disconnectKurssi: disconnectKurssi,
        removeKurssi: removeKurssi
    };
});
//# sourceMappingURL=lukioServices.js.map