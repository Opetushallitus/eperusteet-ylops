"use strict";
var secondJoined = function ($q, parent, resolve) {
    var _q = $q;
    var _parent = parent;
    var _resolver = resolve;
    var _resolved = {};
    var self = {
        clear: function () {
            _parent.clear();
            return self;
        },
        doClear: function () {
            _resolved = {};
            return self;
        },
        get: function (rootId, parentId, id) {
            if (_resolved[rootId] && _resolved[rootId][parentId]) {
                return _q.when(_.cloneDeep(_resolved[rootId][parentId][id]));
            }
            var d = _q.defer();
            _parent.get(rootId, parentId).then(function (parent) {
                if (!_resolved[rootId]) {
                    _resolved[rootId] = {};
                }
                _resolved[rootId][parentId] = _resolver(parent);
                d.resolve(_.cloneDeep(_resolved[rootId][parentId][id]));
            });
            return d.promise;
        }
    };
    return self;
};
var joined = function ($q, parent, resolve) {
    var _q = $q;
    var _parent = parent;
    var _resolver = resolve;
    var _parentId = null;
    var _resolved = {};
    var _related = [];
    var self = {
        clear: function () {
            _parent.clear();
            return self;
        },
        doClear: function () {
            _resolved = {};
            _.each(_related, function (c) { return c.doClear(); });
            return self;
        },
        get: function (parentId, id) {
            if (_resolved[parentId]) {
                return _q.when(_.cloneDeep(_resolved[parentId][id]));
            }
            var d = _q.defer();
            _parent.get(parentId).then(function (parent) {
                _resolved[parentId] = _resolver(parent);
                d.resolve(_.cloneDeep(_resolved[parentId][id]));
            });
            return d.promise;
        },
        related: function (resolve) {
            var j = secondJoined(_q, self, resolve);
            _related.push(j);
            return j;
        }
    };
    return self;
};
var cached = function ($q, resolve) {
    var _q = $q;
    var _resolve = resolve;
    var _initiallyGot = {};
    var _cache = {};
    var _promiseFor = {};
    var _related = [];
    var _onUpdate = [];
    var _alsoClear = [];
    var self = {
        clear: function (id) {
            if (id) {
                delete _cache[id];
            }
            else {
                _cache = {};
            }
            _.each(_related, function (c) { return c.doClear(); });
            _.each(_alsoClear, function (c) { return c.clear(); });
            return self;
        },
        get: function (id) {
            if (_cache[id]) {
                return _q.when(_.cloneDeep(_cache[id]));
            }
            if (_promiseFor[id]) {
                return _promiseFor[id];
            }
            var d = _q.defer();
            _promiseFor[id] = d.promise;
            d.promise.then(function (value) {
                _cache[id] = value;
                var hadValueBefore = _initiallyGot[id];
                _initiallyGot[id] = true;
                delete _promiseFor[id];
                if (hadValueBefore) {
                    _.each(_onUpdate, function (t) { return t(value); });
                }
            });
            _resolve(id, d);
            return d.promise;
        },
        related: function (resolve) {
            var j = joined(_q, self, resolve);
            _related.push(j);
            return j;
        },
        onUpdate: function (then) {
            _onUpdate.push(then);
            return self;
        },
        alsoClear: function (other) {
            _alsoClear.push(other);
            return self;
        }
    };
    return self;
};
//# sourceMappingURL=cache.js.map