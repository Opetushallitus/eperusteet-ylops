"use strict";
var Lokalisointi;
(function (Lokalisointi) {
    function joinString(a, b, key) {
        if (!a[key] && !b[key]) {
            return null;
        }
        return (a[key] || "") + (b[key] || "");
    }
    function join(a, b) {
        return {
            fi: joinString(a, b, "fi"),
            sv: joinString(a, b, "sv"),
            en: joinString(a, b, "en")
        };
    }
    function forAll(constant) {
        return {
            fi: constant,
            sv: constant,
            en: constant
        };
    }
    function concat() {
        var a = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            a[_i] = arguments[_i];
        }
        if (a.length == 0) {
            return forAll(null);
        }
        var j = _.isObject(a[0]) ? a[0] : forAll(a[0]);
        for (var i = 1; i < a.length; ++i) {
            if (a[i]) {
                j = join(j, _.isObject(a[i]) ? a[i] : forAll(a[i]));
            }
        }
        return j;
    }
    Lokalisointi.concat = concat;
})(Lokalisointi || (Lokalisointi = {}));
//# sourceMappingURL=lokalisointi.js.map