"use strict";
ylopsApp.service("Profiili", function ($http, $q) {
    var info = {};
    var prom = $q.defer();
    info.fetchPromise = prom.promise;
    if (!info.$casFetched) {
        info.$casFetched = true;
        $http
            .get("/cas/me")
            .success(function (res) {
            if (res.oid) {
                info.oid = res.oid;
                info.lang = res.lang;
                info.groups = res.groups;
                prom.resolve();
            }
        })
            .error(function () {
            prom.reject();
        });
    }
    return {
        oid: function () {
            return info.oid;
        },
        lang: function () {
            return info.lang;
        },
        groups: function () {
            return info.groups;
        },
        profiili: function () {
            return info;
        }
    };
});
//# sourceMappingURL=profiili.js.map