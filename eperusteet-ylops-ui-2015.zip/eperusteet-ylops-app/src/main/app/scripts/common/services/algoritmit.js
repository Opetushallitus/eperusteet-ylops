"use strict";
ylopsApp.service("Algoritmit", function (Kaanna) {
    function traverse(objekti, lapsienAvain, cb, depth) {
        if (!objekti) {
            return;
        }
        depth = depth || 0;
        _.forEach(objekti[lapsienAvain], function (solmu, index) {
            if (!cb(solmu, depth, index, objekti[lapsienAvain], objekti)) {
                solmu.$$traverseParent = objekti;
                solmu.$$nodeParent = objekti;
                traverse(solmu, lapsienAvain, cb, depth + 1);
            }
        });
    }
    function match(input, to) {
        var vertailu = Kaanna.kaanna(to) || "";
        return vertailu.toLowerCase().indexOf(input.toLowerCase()) !== -1;
    }
    this.traverse = traverse;
    this.match = match;
});
//# sourceMappingURL=algoritmit.js.map