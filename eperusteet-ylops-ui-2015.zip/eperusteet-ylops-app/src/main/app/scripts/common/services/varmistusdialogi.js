"use strict";
ylopsApp
    .service("Varmistusdialogi", function ($modal) {
    var dialogi = function (options) {
        return function (success, failure) {
            var resolve = {
                opts: function () {
                    return {
                        primaryBtn: options.primaryBtn || "ok",
                        primaryBtnClass: options.primaryBtnClass || "",
                        secondaryBtn: options.secondaryBtn || "peruuta"
                    };
                },
                data: function () { return options.data || null; },
                otsikko: function () { return options.otsikko || ""; },
                teksti: function () { return options.teksti || ""; },
                htmlSisalto: function () { return options.htmlSisalto || ""; },
                lisaTeksti: function () { return options.lisaTeksti || ""; },
                comment: function () { return options.comment || ""; }
            };
            var successCb = success || options.successCb || angular.noop;
            var failureCb = failure || options.failureCb || angular.noop;
            $modal
                .open({
                templateUrl: "views/common/modals/varmistusdialogi.html",
                controller: "VarmistusDialogiController",
                resolve: resolve
            })
                .result.then(successCb, failureCb);
        };
    };
    return {
        dialogi: dialogi
    };
})
    .controller("VarmistusDialogiController", function ($scope, $modalInstance, opts, data, otsikko, teksti, htmlSisalto, lisaTeksti, comment) {
    $scope.opts = opts;
    $scope.otsikko = otsikko;
    $scope.teksti = teksti;
    $scope.htmlSisalto = htmlSisalto;
    $scope.lisaTeksti = lisaTeksti;
    $scope.comment = comment;
    $scope.ok = function () {
        if (data !== null) {
            $modalInstance.close(data);
        }
        else {
            $modalInstance.close();
        }
    };
    $scope.peruuta = function () { return $modalInstance.dismiss(); };
});
//# sourceMappingURL=varmistusdialogi.js.map