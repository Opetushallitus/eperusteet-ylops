"use strict";
ylopsApp
    .service("VersionHelper", function ($modal, $state, $stateParams) {
    this.historyView = function (data) {
        $modal
            .open({
            templateUrl: "views/common/modals/versiohelper.html",
            controller: "HistoryViewController",
            resolve: {
                versions: function () {
                    return data;
                }
            }
        })
            .result.then(function (re) {
            var params = _.clone($stateParams);
            var isOppiaine = _.contains($state.current.name, "root.opetussuunnitelmat.yksi.opetus.oppiaine");
            params.versio = re.openOld ? (isOppiaine ? "" : "/") + re.versio.numero : "";
            $state.go($state.current.name, params);
        });
    };
})
    .controller("HistoryViewController", function ($scope, versions, $modalInstance) {
    $scope.versions = versions;
    $scope.close = function (versio, current) {
        if (versio) {
            $modalInstance.close({ versio: versio, openOld: !current });
        }
        else {
            $modalInstance.dismiss();
        }
    };
    $scope.paginate = {
        current: 1,
        perPage: 10
    };
});
//# sourceMappingURL=versionhelper.js.map