"use strict";
ylopsApp
    .service("Utils", function ($window, Kieli, Kaanna) {
    this.scrollTo = function (selector, offset) {
        var element = angular.element(selector);
        if (element.length) {
            $window.scrollTo(0, element.eq(0).offset().top + (offset || 0));
        }
    };
    this.perusteFilter = function (perusteet) { return _.chain(perusteet)
        .filter(function (peruste) { return peruste.tila !== "poistettu"; })
        .filter(function (peruste) { return peruste.toteutus !== "lops2019"; })
        .value(); };
    this.opsFilter = function (opetussuunnitelmat) { return _.chain(opetussuunnitelmat)
        .filter(function (ops) { return ops.tila !== "poistettu"; })
        .filter(function (ops) { return ops.toteutus !== "lops2019"; })
        .value(); };
    this.hasLocalizedText = function (field) {
        if (!_.isObject(field)) {
            return false;
        }
        var hasContent = false;
        var langs = _.values(Kieli.SISALTOKIELET);
        _.each(langs, function (key) {
            if (!_.isEmpty(field[key])) {
                hasContent = true;
            }
        });
        return hasContent;
    };
    this.compareLocalizedText = function (t1, t2) {
        var langs = _.values(Kieli.SISALTOKIELET);
        return _.isEqual(_.pick(t1, langs), _.pick(t2, langs));
    };
    this.supportsFileReader = function () {
        return !_.isUndefined($window.FormData);
    };
    this.sort = function (item) {
        return Kaanna.kaanna(item.nimi, false, true).toLowerCase();
    };
    this.nameSort = function (item, key) {
        return Kaanna.kaanna(key ? item[key] : item.nimi).toLowerCase();
    };
})
    .service("CloneHelper", function () {
    function CloneHelperImpl(keys) {
        this.keys = keys;
        this.stash = {};
    }
    CloneHelperImpl.prototype.clone = function (source, destination) {
        var dest = destination || this.stash;
        var src = source || this.stash;
        _.each(this.keys, function (key) {
            dest[key] = _.cloneDeep(src[key]);
        });
    };
    CloneHelperImpl.prototype.restore = function (destination) {
        this.clone(null, destination);
        this.stash = {};
    };
    CloneHelperImpl.prototype.get = function () {
        return this.stash;
    };
    this.init = function (keys) {
        return new CloneHelperImpl(keys);
    };
})
    .directive("backtotop", function ($window, $document, Utils) {
    var CUTOFF_PERCENTAGE = 33;
    return {
        restrict: "AE",
        scope: {},
        template: '<div id="backtotop" ng-hide="hidden" title="{{tooltip.label | kaanna}}">' +
            '<a class="action-link" icon-role="arrow-up" ng-click="backToTop()"></a></div>',
        link: function (scope) {
            var active = true;
            scope.backToTop = function () {
                Utils.scrollTo("#ylasivuankkuri");
            };
            scope.hidden = true;
            var window = angular.element($window);
            var document = angular.element($document);
            var scroll = function () {
                var fitsOnScreen = document.height() <= window.height() * 1.5;
                var scrollDistance = document.height() - window.height();
                var inTopArea = window.scrollTop() < scrollDistance * CUTOFF_PERCENTAGE / 100;
                scope.$apply(function () {
                    scope.hidden = !active || fitsOnScreen || inTopArea;
                });
            };
            window.on("scroll", scroll);
            scope.$on("enableEditing", function () {
                active = false;
            });
            scope.$on("disableEditing", function () {
                active = true;
            });
            scope.$on("$destroy", function () {
                window.off("scroll", scroll);
            });
        },
        controller: function ($scope) {
            $scope.tooltip = {
                label: "takaisin-ylos"
            };
        }
    };
})
    .directive("dateformatvalidator", function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModel) {
            var parsedMoment = "";
            ngModel.$parsers.unshift(function (viewValue) {
                return validate(viewValue);
            });
            ngModel.$formatters.unshift(function (viewValue) {
                return validate(viewValue);
            });
            function validate(viewValue) {
                if (viewValue instanceof Date ||
                    viewValue === "" ||
                    viewValue === null ||
                    viewValue === undefined) {
                    ngModel.$setValidity("dateformatvalidator", true);
                    return viewValue;
                }
                else if (typeof viewValue === "string") {
                    parsedMoment = moment(viewValue, "D.M.YYYY", true);
                }
                else if (typeof viewValue === "number") {
                    parsedMoment = moment(viewValue);
                }
                else {
                    ngModel.$setValidity("dateformatvalidator", false);
                    return undefined;
                }
                if (parsedMoment.isValid()) {
                    ngModel.$setValidity("dateformatvalidator", true);
                    return viewValue;
                }
                else {
                    ngModel.$setValidity("dateformatvalidator", false);
                    return undefined;
                }
            }
        }
    };
});
//# sourceMappingURL=utils.js.map