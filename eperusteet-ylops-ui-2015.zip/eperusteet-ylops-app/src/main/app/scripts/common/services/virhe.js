"use strict";
ylopsApp
    .controller("VirheController", function ($rootScope, $state, $scope, VirheService) {
    $scope.$watch(VirheService.getData, function (value) {
        $scope.data = value;
    });
    $scope.lisatiedot = $state.params.lisatiedot;
    $scope.lisatiedotCollapsed = true;
    var ls = $rootScope.lastState;
    var opsname = "root.opetussuunnitelmat";
    if (ls.state.name.substr(0, opsname.length) === opsname) {
        $scope.opsId = _.get(ls, "params.id");
    }
    $scope.ylaTila = ls.state.name.replace(/(.[^.]*$)/, "");
    var ylaTila = $state.get($scope.ylaTila);
    $scope.ylaTila = ylaTila && !ylaTila.abstract && $scope.ylaTila;
    var params = {
        id: _.get(ls, "params.id"),
        pohjaId: _.get(ls, "params.pohjaId"),
        vlkId: _.get(ls, "params.vlkId")
    };
    $scope.palaaEdelliseen = function () {
        $state.go(ls.state.name, params);
    };
    $scope.palaaYlempaan = function () {
        $state.go($scope.ylaTila, params);
    };
})
    .service("VirheService", function ($state) {
    var data = {};
    this.setData = function (data) {
        data = data;
    };
    this.getData = function () {
        return data;
    };
    this.virhe = function (virhe, lisatiedot) {
        if (_.isObject(virhe)) {
            data = virhe;
        }
        else {
            data = { muu: virhe };
        }
        $state.go("root.virhe", { lisatiedot: lisatiedot });
    };
});
//# sourceMappingURL=virhe.js.map