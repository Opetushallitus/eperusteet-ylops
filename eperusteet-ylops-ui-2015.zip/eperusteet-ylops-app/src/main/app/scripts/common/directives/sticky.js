"use strict";
var Sticky;
(function (Sticky) {
    Sticky.directive = function () {
        return {
            restrict: "A",
            link: function (scope, element, attrs) {
                $(element).sticky({
                    topSpacing: attrs.topSpacing || 0,
                    className: attrs.classname
                });
            }
        };
    };
})(Sticky || (Sticky = {}));
ylopsApp.directive("sticky", Sticky.directive);
//# sourceMappingURL=sticky.js.map