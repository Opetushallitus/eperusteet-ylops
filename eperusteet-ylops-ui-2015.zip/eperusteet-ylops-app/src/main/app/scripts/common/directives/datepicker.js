"use strict";
ylopsApp.directive("datepickerPopup", [
    "datepickerPopupConfig",
    "dateParser",
    "dateFilter",
    function (datepickerPopupConfig, dateParser, dateFilter) {
        return {
            restrict: "A",
            require: "^ngModel",
            link: function ($scope, element, attrs, ngModel) {
                var dateFormat;
                attrs.$observe("datepickerPopup", function (value) {
                    dateFormat = value || datepickerPopupConfig.datepickerPopup;
                    ngModel.$render();
                });
                ngModel.$formatters.push(function (value) {
                    return ngModel.$isEmpty(value) ? value : dateFilter(value, dateFormat);
                });
            }
        };
    }
]);
//# sourceMappingURL=datepicker.js.map