"use strict";
angular.module("ylopsApp").directive("ohje", function ($rootScope, $timeout, $compile, $document, $window) {
    return {
        templateUrl: "views/common/directives/ohje.html",
        restrict: "EA",
        transclude: true,
        scope: {
            teksti: "@",
            otsikko: "@?",
            suunta: "@?",
            ohje: "@?",
            extra: "="
        },
        link: function (scope, element, attrs) {
            var MAXWIDTH = 400;
            var originalSuunta = scope.suunta;
            function setSuunta() {
                if (!originalSuunta) {
                    var windowWidth = angular.element($window).width();
                    var elOffset = element.offset();
                    if (elOffset.left + MAXWIDTH / 2 > windowWidth) {
                        scope.suunta = "left";
                    }
                    else {
                        scope.suunta = originalSuunta;
                    }
                }
            }
            setSuunta();
            var winEl = angular.element($window);
            winEl.on("resize", setSuunta);
            scope.$on("$destroy", function () {
                winEl.off("resize", setSuunta);
            });
            scope.showing = false;
            var DELAY = 500;
            var timer = null;
            var clickAnywhere = attrs.ohjeClickAnywhere !== "false";
            function appendExtraContent() {
                var content = $compile(scope.extra)(scope);
                element
                    .find(".popover-extra")
                    .empty()
                    .append(content);
            }
            var el = element.find(".popover-element");
            scope.mouseleave = function () {
                $timeout.cancel(timer);
            };
            scope.show = function (visible, mouseEnter) {
                var popupDelay = mouseEnter ? DELAY : 0;
                if (mouseEnter && scope.ohje === "false") {
                    return;
                }
                var opening = angular.isUndefined(visible) || visible;
                if (!scope.showing && !opening) {
                    return;
                }
                if (opening) {
                    $rootScope.$broadcast("ohje:closeAll");
                }
                timer = $timeout(function () {
                    el.trigger(opening ? "show" : "hide");
                    scope.showing = opening;
                    if (opening) {
                        var title = element.find(".popover-title");
                        var closer = $compile(angular.element('<span class="closer pull-right" ng-click="show(false)">&#x2715;</span>'))(scope);
                        title.append(closer);
                        appendExtraContent();
                    }
                }, popupDelay);
            };
            var clickHandler = function (event) {
                if (element.find(event.target).length > 0) {
                    return;
                }
                scope.show(false);
                scope.$apply();
            };
            if (clickAnywhere) {
                $document.on("click", clickHandler);
                scope.$on("$destroy", function () {
                    $document.off("click", clickHandler);
                });
            }
            scope.$on("ohje:closeAll", function () {
                scope.show(false);
            });
            scope.$watch("teksti", function () {
                scope.textObject = scope.$parent.$eval(scope.teksti) || scope.teksti;
            });
            scope.$watch("otsikko", function () {
                scope.title = scope.$parent.$eval(scope.otsikko) || scope.otsikko;
            });
        }
    };
});
angular.module("template/popover/popover.html", []).run([
    "$templateCache",
    function ($templateCache) {
        $templateCache.put("template/popover/popover.html", '<div class="popover {{placement}}" ng-class="{ in: isOpen(), fade: animation() }">\n' +
            '  <div class="arrow"></div>\n' +
            "\n" +
            '  <div class="popover-inner">\n' +
            '      <h3 class="popover-title" ng-bind-html="title | unsafe" ng-show="title"></h3>\n' +
            '      <div class="popover-content" ng-bind-html="content | unsafe"></div>\n' +
            '      <div class="popover-extra"></div>\n' +
            "  </div>\n" +
            "</div>\n" +
            "");
    }
]);
//# sourceMappingURL=ohje.js.map