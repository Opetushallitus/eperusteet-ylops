"use strict";
ylopsApp.directive("slocalized", function ($parse, $rootScope, Kieli) {
    return {
        priority: 5,
        restrict: "A",
        require: "ngModel",
        scope: false,
        link: function (scope, element, attrs, ngModelCtrl) {
            ngModelCtrl.$formatters.push(function (modelValue) {
                if (angular.isUndefined(modelValue)) {
                    return;
                }
                if (modelValue === null) {
                    return;
                }
                return modelValue[Kieli.getSisaltokieli()];
            });
            ngModelCtrl.$parsers.push(function (viewValue) {
                var localizedModelValue = ngModelCtrl.$modelValue;
                if (angular.isUndefined(localizedModelValue)) {
                    localizedModelValue = {};
                }
                if (localizedModelValue === null) {
                    localizedModelValue = {};
                }
                localizedModelValue[Kieli.getSisaltokieli()] = viewValue;
                return localizedModelValue;
            });
            scope.$on("changed:sisaltokieli", function (event, sisaltokieli) {
                if (ngModelCtrl.$modelValue !== null &&
                    !angular.isUndefined(ngModelCtrl.$modelValue) &&
                    !_.isEmpty(ngModelCtrl.$modelValue[sisaltokieli])) {
                    ngModelCtrl.$setViewValue(ngModelCtrl.$modelValue[sisaltokieli]);
                }
                else {
                    ngModelCtrl.$setViewValue("");
                }
                ngModelCtrl.$render();
            });
        }
    };
});
//# sourceMappingURL=localized.js.map