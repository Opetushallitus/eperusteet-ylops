"use strict";
ylopsApp.directive("lukioTree", function () {
    return {
        restrict: "E",
        replace: true,
        scope: {
            rakenne: "=",
            root: "="
        },
        templateUrl: "views/common/directives/lukiotree.html",
        controller: function ($scope, $log, $modal, $stateParams, Algoritmit, LukioTreeUtils) {
            $scope.stateParams = $stateParams;
            $scope.sortableConfig = {
                handle: ".tree-handle",
                helper: "clone",
                axis: "y",
                cursor: "move",
                delay: 100,
                placeholder: "lukio-tree-placeholder",
                opacity: 0.5,
                tolerance: "pointer",
                disabled: true
            };
            $scope.poista = function (node) {
                _.remove(node.$$nodeParent.lapset, node);
            };
            $scope.lisaa = function (node) {
                $modal.open({
                    templateUrl: "views/opetussuunnitelmat/modals/kurssi.html",
                    controller: "LukioTreeModalController",
                    size: "lg",
                    resolve: {
                        rakenne: _.constant(_.cloneDeep($scope.rakenne)),
                        root: _.constant(_.cloneDeep($scope.root))
                    },
                    backdrop: 'static',
                    keyboard: false
                }).result.then(function (kurssit) {
                    var kurssitMap = _.indexBy(node.lapset, "id");
                    _.each(kurssit, function (kurssi) {
                        if (!_.has(kurssitMap, kurssi.id)) {
                            node.lapset.push(kurssi);
                        }
                    });
                });
            };
            $scope.$on("enableEditing", function () {
                LukioTreeUtils.search($scope.root, "");
                $scope.sortableConfig.disabled = false;
            });
            $scope.$on("disableEditing", function () {
                $scope.sortableConfig.disabled = true;
            });
        }
    };
}).controller("LukioTreeModalController", function ($scope, $modalInstance, $timeout, LukioTreeUtils, rakenne, root) {
    var resolveKurssit = function (node) {
        var kurssit = _(node)
            .flattenTree(function (n) { return n.lapset; })
            .filter(function (c) { return c.dtype == LukioKurssiTreeNodeType.kurssi; })
            .value();
        return _.uniq(kurssit, "id");
    };
    var resolveLiittamattomatKurssit = function () {
        var kaikkiKurssit = resolveKurssit(LukioTreeUtils.buildTree(rakenne));
        var liitetytKurssit = resolveKurssit(root);
        var liitetytKurssitMap = _.indexBy(liitetytKurssit, "id");
        return _.filter(kaikkiKurssit, function (k) { return !_.has(liitetytKurssitMap, k.id); });
    };
    $scope.liittamattomatHaku = "";
    $scope.liitetytHaku = "";
    $scope.lisattavatKurssit = [];
    $scope.liittamattomatKurssit = resolveLiittamattomatKurssit();
    $scope.liitetytKurssit = resolveKurssit(root);
    _.each($scope.liitetytKurssit, function (kurssi) {
        kurssi.$$lisatty = false;
    });
    $scope.liittamattomatHae = function () {
        $timeout(function () {
            LukioTreeUtils.search($scope.liittamattomatKurssit, $scope.liittamattomatHaku);
        });
    };
    $scope.liitetytHae = function () {
        $timeout(function () {
            LukioTreeUtils.search($scope.liitetytKurssit, $scope.liitetytHaku);
        });
    };
    $scope.lisaaKurssi = function (kurssi) {
        if (!_.includes($scope.lisattavatKurssit, { id: kurssi.id })) {
            $scope.lisattavatKurssit.push(kurssi);
            kurssi.$$lisatty = true;
        }
    };
    $scope.poistaKurssi = function (kurssi) {
        _.remove($scope.lisattavatKurssit, kurssi);
        kurssi.$$lisatty = false;
    };
    $scope.lisaa = function () {
        $modalInstance.close($scope.lisattavatKurssit);
    };
});
//# sourceMappingURL=lukiotree.js.map