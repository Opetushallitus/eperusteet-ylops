"use strict";
ylopsApp.directive("jquerySpinner", function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, c) {
            var $e = $(element);
            $e.spinner({
                spin: function (event, ui) { return c.$setViewValue(ui.value); },
                change: function () {
                    var value = parseFloat(("" + $e.val()).trim().replace(",", "."));
                    $e.val(value);
                    c.$setViewValue(value);
                }
            });
        }
    };
});
//# sourceMappingURL=jqueryspinner.js.map