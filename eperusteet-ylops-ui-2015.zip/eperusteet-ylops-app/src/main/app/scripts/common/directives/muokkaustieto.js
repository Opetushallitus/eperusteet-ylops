"use strict";
angular.module("ylopsApp").directive("muokkaustieto", function ($rootScope, EperusteetKayttajatiedot) {
    return {
        template: '<div ng-if="tiedot && tiedot.luotu" class="dir-muokkaustieto">' +
            "  <span>" +
            '    <span class="muokkaustieto-topic" kaanna="muokattu-viimeksi"></span>:' +
            '    <span class="muokkaustieto-data" ng-bind="(tiedot.muokattu || tiedot.luotu) | aikaleima"></span>' +
            "  </span>" +
            '  <span style="margin-left: 5px" ng-if="muokkaajanNimi">' +
            '    <span class="muokkaustieto-topic" kaanna="muokkaaja"></span>:' +
            '    <span class="muokkaustieto-data" ng-bind="muokkaajanNimi"></span>' +
            "  </span>" +
            "</div>",
        scope: {
            tiedot: "="
        },
        controller: function ($scope) {
            $scope.$watch("tiedot", function (tiedot) {
                if (tiedot && tiedot.muokkaajaOid) {
                    EperusteetKayttajatiedot.get({
                        oid: tiedot.muokkaajaOid
                    }, function (res) {
                        if (res.sukunimi && (res.kutsumanimi || res.etunimet)) {
                            $scope.muokkaajanNimi = (res.kutsumanimi || res.etunimet) + " " + res.sukunimi;
                        }
                    });
                }
            }, true);
        }
    };
});
//# sourceMappingURL=muokkaustieto.js.map