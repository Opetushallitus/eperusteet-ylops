"use strict";
ylopsApp
    .service("SpinnerService", function (SPINNER_WAIT, $rootScope, $timeout, cfpLoadingBar) {
    var pyynnot = 0;
    function enableSpinner() {
        cfpLoadingBar.start();
        ++pyynnot;
        $timeout(function () {
            if (pyynnot > 0) {
                $rootScope.$emit("event:spinner_on");
            }
        }, SPINNER_WAIT);
    }
    function disableSpinner() {
        cfpLoadingBar.complete();
        --pyynnot;
        if (pyynnot === 0) {
            $rootScope.$emit("event:spinner_off");
        }
    }
    return {
        enable: enableSpinner,
        disable: disableSpinner,
        isSpinning: function () {
            return pyynnot > 0;
        }
    };
})
    .directive("spinner", function () {
    return {
        template: '<div id="global-spinner" ng-show="isSpinning">' +
            '<span class="glyphicon glyphicon-refresh spin"></span>' +
            "</div>",
        restrict: "E",
        link: function ($scope) {
            $scope.isSpinning = false;
            function spin(state) {
                $scope.isSpinning = state;
            }
            $scope.$on("event:spinner_on", function () {
                spin(true);
            });
            $scope.$on("event:spinner_off", function () {
                spin(false);
            });
        }
    };
})
    .directive("smallSpinner", function () {
    return {
        restrict: "EA",
        link: function (scope, element) {
            element.prepend('<img class="small-spinner" src="images/spinner-small.gif" alt="">');
        }
    };
});
//# sourceMappingURL=spinner.js.map