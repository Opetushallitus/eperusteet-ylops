"use strict";
ylopsApp.directive("versiotiedot", function (VersionHelper, $q) {
    return {
        templateUrl: "views/common/directives/versiotiedot.html",
        restrict: "E",
        controller: function ($scope, EperusteetKayttajatiedot) {
            var reqs = [];
            _.forEach(_.uniq($scope.versiot.list, "muokkaajaOid"), function (i) {
                return reqs.push(EperusteetKayttajatiedot.get({ oid: i.muokkaajaOid }).$promise);
            });
            $q.all(reqs).then(function (values) {
                _.forEach($scope.versiot.list, function (name) {
                    var henkilo = _.find(values, function (i) { return i.oidHenkilo === name.muokkaajaOid; });
                    var nimi = _.isEmpty(henkilo)
                        ? " "
                        : (henkilo.kutsumanimi || "") + " " + (henkilo.sukunimi || "");
                    name.muokkaaja = nimi === " " ? name.muokkaajaOid : nimi;
                });
            });
            $scope.history = function () {
                VersionHelper.historyView($scope.versiot);
            };
        }
    };
});
//# sourceMappingURL=versiotiedot.js.map