"use strict";
ylopsApp
    .directive("editointikontrollit", function ($window) {
    return {
        templateUrl: "views/common/directives/editointikontrollit.html",
        restrict: "E",
        link: function (scope) {
            var window = angular.element($window), container = angular.element(".edit-controls"), wrapper = angular.element(".editointi-wrapper");
            scope.updatePosition = function () {
                if (window.scrollTop() + window.innerHeight() < wrapper.offset().top + container.height()) {
                    container.addClass("floating");
                    container.removeClass("static");
                    container.css("width", wrapper.width());
                }
                else {
                    container.removeClass("floating");
                    container.addClass("static");
                    container.css("width", "100%");
                }
            };
            var updatepos = function () {
                scope.updatePosition();
            };
            window.on("scroll resize", updatepos);
            scope.$on("$destroy", function () {
                window.off("scroll resize", updatepos);
            });
            scope.updatePosition();
            scope.setMargins = function () {
                if (scope.editStarted) {
                    wrapper.css("margin-bottom", "50px").css("margin-top", "20px");
                }
                else {
                    wrapper.css("margin-bottom", 0).css("margin-top", 0);
                }
            };
            scope.setMargins();
        }
    };
})
    .controller("EditointiController", function ($scope, $rootScope, Editointikontrollit, $timeout) {
    $scope.kommentti = "";
    $scope.hideControls = true;
    function setEditControls() {
        if (Editointikontrollit.editingEnabled()) {
            $scope.hideControls = false;
        }
        else {
            $scope.hideControls = true;
            $scope.editStarted = false;
        }
    }
    setEditControls();
    $scope.$on("$stateChangeStart", function () {
        Editointikontrollit.unregisterCallback();
        setEditControls();
    });
    Editointikontrollit.registerCallbackListener(setEditControls);
    $scope.$on("editointikontrollitRefresh", function () {
        $scope.updatePosition();
    });
    $scope.$on("enableEditing", function () {
        $scope.editStarted = true;
        $scope.setMargins();
        $scope.kommentti = "";
        $timeout(function () {
            $scope.updatePosition();
        });
    });
    $scope.$on("disableEditing", function () {
        $scope.editStarted = false;
        $scope.setMargins();
    });
    $scope.start = function () {
        Editointikontrollit.startEditing();
    };
    $scope.save = function () {
        Editointikontrollit.saveEditing($scope.kommentti);
    };
    $scope.cancel = function () {
        Editointikontrollit.cancelEditing();
    };
});
//# sourceMappingURL=editointikontrollit.js.map