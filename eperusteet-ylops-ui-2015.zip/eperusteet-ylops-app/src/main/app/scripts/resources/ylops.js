"use strict";
angular.module("ylopsApp").factory("Api", function (Restangular, Notifikaatiot, Kaanna) {
    return Restangular.withConfig(function (config) {
        config.setBaseUrl("/eperusteet-ylops-service/api");
        config.setResponseInterceptor(function (data, operation, what, url, response, deferred) {
            if (response && response.status >= 400) {
                if (response.status >= 500) {
                }
                else if (response.data && response.data.syy) {
                    var syy = response.data.syy;
                    Notifikaatiot.varoitus(_.isArray(syy) ? syy[0] : syy);
                }
                else {
                    Notifikaatiot.varoitus(Kaanna.kaanna("odottamaton-virhe"));
                }
            }
            return data;
        });
    });
});
//# sourceMappingURL=ylops.js.map