declare var CKEDITOR: any;
declare var XLSX: any;
declare var _: any;
declare var moment: any;
declare var window: Window;

// TODO: Vaihda typealiaksiin
interface IPromise<T> extends angular.IPromise<T> {}
interface IQService extends angular.IQService {}
interface IDeferred<T> extends angular.IDeferred<T> {}
